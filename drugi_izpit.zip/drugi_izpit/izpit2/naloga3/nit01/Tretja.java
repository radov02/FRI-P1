
/*
Samodejno testiranje:

tj.exe

Javni testni primeri:

01--06: ro"cno izdelani
07--12: samodejno izdelani

01--02, 07--08: klici metode steviloStanovanj
03--04, 09--10: klici metode koliko
05--06, 11--12: klici metode poslovnaCetrt

01, 03, 05, 07, 09, 11: brez ru"senja
02, 04, 06, 08, 10, 12: z ru"senjem
*/

import java.util.*;

public class Tretja {

    public static void main(String[] args) {
        // dopolnite za potrebe ro"cnega testiranja
    }

    //=========================================================================

    public static abstract class Stavba {
        // po potrebi dopolnite ...
        public abstract String tip();
    }

    //=========================================================================

    public static class Stanovanjska extends Stavba {
        private int stStanovanj;   // "stevilo stanovanj

        public Stanovanjska(int stStanovanj) {
            this.stStanovanj = stStanovanj;
        }

        public int steviloStanovanj() {
            return this.stStanovanj;
        }

        public String tip(){
            return "Stanovanjska";
        }

        // po potrebi dopolnite ...
    }

    //=========================================================================

    public static class Poslovna extends Stavba {
        // po potrebi dopolnite ...
        public String tip(){
            return "Poslovna";
        }
    }

    //=========================================================================

    public static class Mesto {
        public Stavba[][] stavbe;
        // po potrebi dopolnite ...

        public Mesto(int stVrstic, int stStolpcev) {
            stavbe = new Stavba[stVrstic][stStolpcev];
        }

        public void postavi(int vrstica, int stolpec, Stavba stavba) {
            stavbe[vrstica][stolpec] = stavba;
        }

        public int steviloStanovanj() {
            int stevec = 0;
            for(int i = 0; i < stavbe.length; i++){
                for(int j = 0; j < stavbe[i].length; j++){
                    if(stavbe[i][j] instanceof Stanovanjska){
                        Stanovanjska sta = (Stanovanjska)stavbe[i][j];
                        stevec += sta.steviloStanovanj();
                    }
                }
            }
            return stevec;
        }

        public int koliko(Stavba stavba) {
            int stevec = 0;
            for(int i = 0; i < stavbe.length; i++){
                for(int j = 0; j < stavbe[i].length; j++){
                    if(stavbe[i][j] != null && stavba.tip().equals(stavbe[i][j].tip())){
                        stevec++;
                    }
                }
            }
            return stevec;
        }

        //
        // Velja 
        // 0 <= vrZac <= vrKon < this.stVrstic
        // in
        // 0 <= stZac <= stKon < this.stStolpcev.
        //
        public boolean poslovnaCetrt(int vrZac, int stZac, int vrKon, int stKon) {
            for(int i = vrZac; i <= vrKon; i++){
                for(int j = stZac; j <= stKon; j++){
                    if(stavbe[i][j] != null && !stavbe[i][j].tip().equals("Poslovna")){
                        return false;
                    }
                    if(stavbe[i][j] == null) return false;
                }
            }
            return true;
        }

        // pomo"zne metode (po potrebi) ...
    }

    //=========================================================================

    // drugi notranji razredi (po potrebi) ...
}
