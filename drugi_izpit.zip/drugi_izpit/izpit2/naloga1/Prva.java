
/*
Samodejno testiranje:

tj.exe Prva.java . .

Javni testni primeri:

01: primer iz besedila
02--10: splošni primeri
*/

import java.util.*;

public class Prva {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int p = sc.nextInt();
        int q = sc.nextInt();
        int n = sc.nextInt();

        int[] zap = new int[n];
        for(int i = 0; i < n; i++){
            zap[i] = sc.nextInt();
        }
        sc.close();

        int[] prast = prastevil(150000);

        for(int i = 0; i < n; i++){
            int stevilo = zap[i];
            boolean b = true;

            if(stevilo != 1) {
                for(int j = 0; j < prast.length; j++){
                    if(stevilo % prast[j] == 0 && prast[j] != p && prast[j] != q){
                        b = false;
                        break;
                    }
                }
            }
            else {
                b = true;
            }

            if(!b) System.out.println("NE");
            else System.out.println("DA");
        }
    }

    private static int[] prastevil(int st){
        int[] prast = new int[st];
        prast[0] = 2;
        int indeks = 1;
        int i = 3;

        while(indeks < st){
            if(jePrastevilo(i)){
                prast[indeks++] = i;
            }
            i += 2;
        }
        return prast;
    }

    private static boolean jePrastevilo(int st){
        for(int i = 2; i <= (int)Math.sqrt(st); i++){
            if(st % i == 0) return false;
        }
        return true;
    }

    // pomo"zne metode, notranji razredi (po potrebi) ...
}

/* public class Prva {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int p = sc.nextInt();
        int q = sc.nextInt();
        int n = sc.nextInt();

        int[] tab = new int[n];

        for (int i = 0; i < tab.length; i++) {
            tab[i] = sc.nextInt();
        }

        for (int i = 0; i < tab.length; i++) {
            if (jeMogoce(p, q, tab[i])) {
                System.out.println("DA");
            } else {
                System.out.println("NE");
            }
        }
    }

    public static boolean jeMogoce(int p, int q, int n) {

        for (int i = 0; i < 100; i++) {
            for (int j = 0; j < 100; j++) {
                if (Math.pow(p, i)*Math.pow(q, j) == n) {
                    return true;
                }
            }
        }
        return false;
    }

    // pomo"zne metode, notranji razredi (po potrebi) ...
} */