
/*
Samodejno testiranje:

tj.exe

Javni testni primeri:

01: primer iz besedila
02: vse smeri so 1 ali 2, ostalo enako kot v besedilu
02--06: vse smeri so 1 ali 2
01, 07--10: splo"sni primeri

V vseh testnih primerih (javnih in skritih) so elementi tabele <rel>
"stevila z intervala [-1000, 1000].
*/

import java.util.*;

public class Druga {

    public static void main(String[] args) {
        // dopolnite za potrebe ro"cnega testiranja
    }

    public static int[][] visine(int[][] rel, int[][] smer) {
        int[][] nm = new int[rel.length][rel[0].length];

        for(int i = 0; i < nm.length; i++){
            for(int j = 0; j < nm[i].length; j++){
                if(i == 0 && j == 0) continue;
                int smer1 = smer[i][j];
                if(smer1 == 1){
                    nm[i][j] += nm[i][j-1] + rel[i][j];
                }
                else if(smer1 == 2){
                    nm[i][j] += nm[i-1][j] + rel[i][j];
                }
                else if(smer1 == 3){
                    int smer2 = smer[i][j+1];
                    

                    nm[i][j] = nm[i][j+1] + rel[i][j];
                }
                else if(smer1 == 4){
                    nm[i][j] = nm[i+1][j] + rel[i][j];
                }
            }
        }
        return nm;
    }

    // pomo"zne metode, notranji razredi (po potrebi) ...
    private static int izracunVisine(int[][] rel, int[][] smer){
        return 0;
    }
}
