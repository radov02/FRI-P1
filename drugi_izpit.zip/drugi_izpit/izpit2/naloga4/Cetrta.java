
/*
Samodejno testiranje:

tj.exe

Javni testni primeri:

01, 02: ro"cno izdelana
03--10: samodejno izdelani

01, 03--06: klici metode alternirajoceMonotono
02, 07--10: klici metode generator
*/

import java.util.*;
import java.util.function.*;

public class Cetrta {

    public static void main(String[] args) {
        // dopolnite za potrebe ro"cnega testiranja
    }

    public static <T> boolean alternirajoceMonotono(List<T> zaporedje, Comparator<T> prim) {
        if(zaporedje.size() <= 2) return true;

        for(int i = 0; i < zaporedje.size()-2; i+=2){
            for(int j = i+2; j < zaporedje.size(); j+=2){
                if(prim.compare(zaporedje.get(i), zaporedje.get(j)) >= 0){
                    return false;
                }
            }
        }
        for(int i = 1; i < zaporedje.size()-2; i+=2){
            for(int j = i+2; j < zaporedje.size(); j+=2){
                if(prim.compare(zaporedje.get(i), zaporedje.get(j)) <= 0){
                    return false;
                }
            }
        }
        return true;
    }

    public static Supplier<Integer> generator(int a, int b) {
        
        return new Supplier<Integer>(){

            double kratnikb = 0;
            int predznak = 1;

            @Override
            public Integer get(){
                Integer in = a + predznak*(int)Math.ceil(kratnikb)*b;
                predznak = -1*predznak;
                kratnikb += 0.5;
                return in;
            }
        };
    }

    // pomo"zne metode, notranji razredi (po potrebi) ...
}
