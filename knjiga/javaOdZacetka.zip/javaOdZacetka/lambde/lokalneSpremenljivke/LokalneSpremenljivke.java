
//
// Dokaz, da lahko v lambdi uporabljamo lokalne spremenljivke, definirane
// izven lambde.
//

import java.util.function.*;

public class LokalneSpremenljivke {

    public static void main(String[] args) {
        IntUnaryOperator krat5 = mnozilnik(5);
        System.out.println(krat5.applyAsInt(3));
        System.out.println(krat5.applyAsInt(10));
    }

    //
    // Vrne funkcijo, ki sprejme število, vrne pa /faktor/-kratnik tega
    // števila.
    //
    public static IntUnaryOperator mnozilnik(int faktor) {
        // spremenljivke faktor ne smemo spreminjati!
        return n -> n * faktor;
    }
}
