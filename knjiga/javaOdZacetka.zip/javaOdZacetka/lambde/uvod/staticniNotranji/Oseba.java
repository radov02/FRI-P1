
//
// Razred za predstavitev posameznih oseb.
//

import java.util.*;

public class Oseba {
    private String ime;
    private String priimek;
    private char spol;
    private int letoRojstva;

    //
    // Inicializira novoustvarjeni objekt tako, da predstavlja oseba s podanim
    // imenom, priimkom, spolom in letom rojstva.
    //
    public Oseba(String ime, String priimek, char spol, int letoRojstva) {
        this.ime = ime;
        this.priimek = priimek;
        this.spol = spol;
        this.letoRojstva = letoRojstva;
    }

    //
    // Vrne niz sledeče oblike:
    // ime priimek (spol), letoRojstva
    //
    @Override
    public String toString() {
        return String.format("%s %s (%c), %d",
                this.ime, this.priimek, this.spol, this.letoRojstva);
    }

    //
    // Razred za primerjalnik, ki podani osebi primerja primarno po spolu,
    // sekundarno pa po starosti.
    //
    private static class PrimerjalnikSpolStarost implements Comparator<Oseba> {
        @Override
        public int compare(Oseba prva, Oseba druga) {
            if (prva.spol != druga.spol) {
                return druga.spol - prva.spol;
            }
            return prva.letoRojstva - druga.letoRojstva;
        }
    }

    //
    // Vrne primerjalnik, ki podani osebi primerja po spolu (primarno) in
    // starosti (sekundarno).
    //
    public static Comparator<Oseba> primerjalnikSpolStarost() {
        return new PrimerjalnikSpolStarost();
    }
}
