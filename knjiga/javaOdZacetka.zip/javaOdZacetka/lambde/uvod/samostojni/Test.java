
//
// Testni razred.
//

import java.util.*;

public class Test {

    public static void main(String[] args) {
        List<Oseba> osebe = new ArrayList<>(List.of(
            new Oseba("Ana",    "Antolin",  'Z', 1980),
            new Oseba("Bojan",  "Bevk",     'M', 1972),
            new Oseba("Cvetka", "Cedilnik", 'Z', 1948),
            new Oseba("Denis",  "Doblekar", 'M', 1979),
            new Oseba("Eva",    "Ertl",     'Z', 2005),
            new Oseba("Filip",  "Ferlinc",  'M', 2011),
            new Oseba("Gorazd", "Gabrc",    'M', 1965),
            new Oseba("Helga",  "Hojnik",   'Z', 1952),
            new Oseba("Iva",    "Ivnik",    'Z', 1997),
            new Oseba("Janez",  "Jevc",     'M', 1975)
        ));

        osebe.sort(Oseba.primerjalnikSpolStarost());

        for (Oseba oseba: osebe) {
            System.out.println(oseba);
        }
    }
}
