
//
// Razred za primerjalnik, ki primerja podani osebi primarno po spolu,
// sekundarno pa po starosti.
//

import java.util.*;

public class PrimerjalnikSpolStarost implements Comparator<Oseba> {

    @Override
    public int compare(Oseba prva, Oseba druga) {
        if (prva.vrniSpol() != druga.vrniSpol()) {
            return druga.vrniSpol() - prva.vrniSpol();
        }
        return prva.vrniLetoRojstva() - druga.vrniLetoRojstva();
    }
}
