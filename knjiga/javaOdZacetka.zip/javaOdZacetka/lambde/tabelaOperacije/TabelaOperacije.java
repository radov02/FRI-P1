
//
// Program nariše tabelo dvojiške operacije.  Dvojiško operacijo predstavimo
// kot objekt, ki ga izdelamo z lambdo.
//

import java.util.function.IntBinaryOperator;

public class TabelaOperacije {

    public static void main(String[] args) {

        // klic metode tabelaOperacije z objektom, ustvarjenim z lambdo
        tabelaOperacije(5, (a, b) -> a * b);

        System.out.println();

        // klic metode tabelaOperacije z objektom anonimnega notranjega
        // razreda
        tabelaOperacije(5, new IntBinaryOperator() {
            @Override
            public int applyAsInt(int a, int b) {
                return a * b;
            }
        });
    }

    //
    // Izpiše tabelo velikosti n x n, v kateri element v vrstici i in stolpcu
    // j podaja rezultat dvojiške operacije nad argumentoma i in j.  Dvojiška
    // operacija je predstavljena s parametrom /op/.
    //
    public static void tabelaOperacije(int n, IntBinaryOperator op) {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                System.out.printf(" %3d", op.applyAsInt(i, j));
            }
            System.out.println();
        }
    }
}
