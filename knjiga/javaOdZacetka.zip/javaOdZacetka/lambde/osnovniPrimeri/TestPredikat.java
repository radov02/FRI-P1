
//
// Nekaj definicij objektov tipa Predikat s pomočjo lambd in enakovrednih
// notranjih razredov.
//

import java.util.*;

public class TestPredikat {

    public static void main(String[] args) {
        System.out.println("--- nizi ---");

        List<String> besede = List.of(
            "podatki", "program", "programiranje",
            "metoda", "funkcija", "lambda", "vsebovalnik"
        );

        // objekt, ki predstavlja predikat "je dolg vsaj 10"
        // (izdelan z lambdo)
        Predikat<String> dolg = (String a) -> { return a.length() >= 10; };

        // objekt, ki predstavlja predikat "je dolg vsaj 10"
        // (izdelan kot objekt anonimnega notranjega razreda)
        Predikat<String> dolg2 = new Predikat<>() {
            @Override
            public boolean preveri(String a) {
                return a.length() >= 10;
            }
        };

        System.out.println(dolg.preveri("Maksimilijan"));
        System.out.println(dolg2.preveri("Maksimilijan"));

        System.out.println(dolg.preveri("Maks"));
        System.out.println(dolg2.preveri("Maks"));

        System.out.println(poisciPrvega(besede, dolg));
        System.out.println(poisciPrvega(besede, dolg2));
        System.out.println();

        System.out.println("--- časi ---");

        List<Cas> casi = List.of(
            new Cas(10, 20), new Cas(7, 30), new Cas(15, 10), new Cas(13, 40)
        );

        System.out.println(poisciPrvega(
            casi,
            (Cas cas) -> { return cas.compareTo(new Cas(12, 0)) > 0; }
        ));

        System.out.println(poisciPrvega(
            casi,
            new Predikat<Cas>() {
                @Override
                public boolean preveri(Cas cas) {
                    return cas.compareTo(new Cas(12, 0)) > 0;
                }
            }
        ));

        System.out.println();

        System.out.println("--- števila ---");

        List<Integer> stevila = List.of(10, 20, 30, 40, 50, 60, 70, 80, 90, 100);

        System.out.println(poisciPrvega(stevila, jeDeljivZ_lambda(7)));
        System.out.println(poisciPrvega(stevila, jeDeljivZ_anonimni(7)));
        System.out.println(poisciPrvega(stevila, jeDeljivZ_notranji(7)));
    }

    //
    // Vrne prvi element podanega seznama, za katerega je podani predikat
    // resničen.
    //
    public static <T> T poisciPrvega(List<T> seznam, Predikat<T> predikat) {
        for (T element: seznam) {
            if (predikat.preveri(element)) {
                return element;
            }
        }
        return null;
    }

    //
    // Vrne objekt, ki predstavlja predikat "je deljiv s številom /delitelj/".
    // Objekt izdelamo z lambdo.
    //
    public static Predikat<Integer> jeDeljivZ_lambda(int delitelj) {
        return (Integer stevilo) -> { return stevilo % delitelj == 0; };
    }

    //
    // Vrne objekt, ki predstavlja predikat "je deljiv s številom /delitelj/".
    // Objekt izdelamo kot objekt anonimnega notranjega razreda.
    //
    public static Predikat<Integer> jeDeljivZ_anonimni(int delitelj) {
        return new Predikat<>() {
            @Override
            public boolean preveri(Integer stevilo) {
                return stevilo % delitelj == 0;
            }
        };
    }

    //
    // Vrne objekt, ki predstavlja predikat "je deljiv s številom /delitelj/".
    // Objekt izdelamo kot objekt statičnega notranjega razreda.
    //
    public static Predikat<Integer> jeDeljivZ_notranji(int delitelj) {
        return new Deljiv(delitelj);
    }

    private static class Deljiv implements Predikat<Integer> {
        private int delitelj;

        public Deljiv(int delitelj) {
            this.delitelj = delitelj;
        }

        @Override
        public boolean preveri(Integer stevilo) {
            return stevilo % this.delitelj == 0;
        }
    }
}
