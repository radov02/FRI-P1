
//
// Izdelava objekta tipa DvojiskaFunkcija s pomočjo lambde ter enakovrednega
// anonimnega in statičnega notranjih razredov.
//

import java.util.*;

public class TestDvojiskaFunkcija {

    public static void main(String[] args) {
        // izdelava s pomočjo lambde
        DvojiskaFunkcija<String, Integer, Character> izlusciZnak = 
            (String niz, Integer indeks) -> { return niz.charAt(indeks); };

        // izdelava s pomočjo anonimnega notranjega razreda
        DvojiskaFunkcija<String, Integer, Character> izlusciZnak2 = 
            new DvojiskaFunkcija<>() {
                @Override
                public Character izvedi(String niz, Integer indeks) {
                    return niz.charAt(indeks);
                }
            };

        // izdelava s pomočjo statičnega notranjega razreda
        DvojiskaFunkcija<String, Integer, Character> izlusciZnak3 = new IzlusciZnak();

        System.out.println(izlusciZnak.izvedi("programiranje", 3));
        System.out.println(izlusciZnak2.izvedi("programiranje", 3));
        System.out.println(izlusciZnak3.izvedi("programiranje", 3));

        List<String> nizi = List.of("najraje", "programiramo", "v", "javi");
        List<Integer> indeksi = List.of(5, 9, 0, 1);

        System.out.println(uporabi(izlusciZnak, nizi, indeksi));
        System.out.println(uporabi(izlusciZnak2, nizi, indeksi));
        System.out.println(uporabi(izlusciZnak3, nizi, indeksi));
    }

    //
    // Objekt tega razreda predstavlja funkcijo, ki za podani niz vrne znak s
    // podanim indeksom.
    //
    private static class IzlusciZnak implements DvojiskaFunkcija<String, Integer, Character> {
        @Override
        public Character izvedi(String niz, Integer indeks) {
            return niz.charAt(indeks);
        }
    }

    //
    // Vrne seznam rezultatov uporabe podane funkcije na istoležnih elementih
    // seznamov a in b.  Metoda predpostavlja, da sta seznama a in b enako
    // dolga.
    //
    private static <T, U, R> List<R> uporabi(DvojiskaFunkcija<T, U, R> f, List<T> a, List<U> b) {
        List<R> rezultat = new ArrayList<>();
        int n = a.size();
        for (int i = 0; i < n; i++) {
            rezultat.add(f.izvedi(a.get(i), b.get(i)));
        }
        return rezultat;
    }
}
