
//
// Objekt tega vmesnika predstavlja funkcijo, ki sprejme parameter tipa T in
// vrne logično vrednost.
//

public interface Predikat<T> {
    public abstract boolean preveri(T a);
}
