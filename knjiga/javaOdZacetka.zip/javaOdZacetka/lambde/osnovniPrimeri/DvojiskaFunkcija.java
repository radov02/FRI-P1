
//
// Objekt tega vmesnika predstavlja funkcijo, ki sprejme parametra tipov T in
// U in vrne rezultat tipa R.
//

public interface DvojiskaFunkcija<T, U, R> {
    public abstract R izvedi(T a, U b);
}
