
import java.util.*;
import java.io.*;     // razredi za delo z datotekami

public class ObdelajIzpit {

    public static void main(String[] args) {
        String datStudentje = args[0];
        int stNalog = args.length - 3;

        String[] datNaloge = new String[stNalog];
        for (int i = 0; i < stNalog; i++) {
            datNaloge[i] = args[i + 1];
        }
        String datPoPriimkih = args[args.length - 2];
        String datPoTockah = args[args.length - 1];

        Map<String, Student> vpisna2student = preberiStudente(datStudentje);
        Map<String, List<Integer>> vpisna2tocke = preberiTocke(datNaloge);

        List<String> vpisne = new ArrayList<>(vpisna2student.keySet());

        vpisne.sort((vp1, vp2) -> 
                    vpisna2student.get(vp1).primerjaj(vpisna2student.get(vp2)));
        izpisi(vpisne, vpisna2student, vpisna2tocke, stNalog, datPoPriimkih);

        vpisne.sort((vp1, vp2) ->
                    vsota(vpisna2tocke.get(vp2)) - vsota(vpisna2tocke.get(vp1)));
        izpisi(vpisne, vpisna2student, vpisna2tocke, stNalog, datPoTockah);
    }

    private static Map<String, Student> preberiStudente(String datoteka) {
        Map<String, Student> vpisna2student = new HashMap<>();

        int stVrstice = 2;
        try (Scanner sc = new Scanner(new File(datoteka))) {
            sc.nextLine();   // preskočimo glavo
            while (sc.hasNextLine()) {
                String vrstica = sc.nextLine();
                String[] komponente = vrstica.split(";");
                String vpisna = komponente[0];
                String ime = komponente[1];
                String priimek = komponente[2];
                vpisna2student.put(vpisna, new Student(vpisna, ime, priimek));
                stVrstice++;
            }
        } catch (FileNotFoundException ex) {
            System.err.printf("Datoteka %s ne obstaja.%n", datoteka);
        } catch (ArrayIndexOutOfBoundsException ex) {
            System.err.printf("Datoteka %s: napaka v %d.  vrstici%n",
                    datoteka, stVrstice);
        }

        return vpisna2student;
    }

    private static Map<String, List<Integer>> preberiTocke(String[] datoteke) {
        int stNalog = datoteke.length;
        Map<String, List<Integer>> vpisna2tocke = new HashMap<>();

        for (int iNaloga = 0; iNaloga < datoteke.length; iNaloga++) {
            try (Scanner sc = new Scanner(new File(datoteke[iNaloga]))) {
                sc.nextLine();   // preskočimo glavo
                while (sc.hasNextLine()) {
                    String vrstica = sc.nextLine();
                    String[] komponente = vrstica.split(";");
                    String vpisna = komponente[0];
                    int tocke = 0;
                    for (int t = 1; t < komponente.length; t++) {
                        tocke += Integer.parseInt(komponente[t]);
                    }
                    List<Integer> tockeNalog = vpisna2tocke.get(vpisna);  // (1)
                    if (tockeNalog == null) {
                        tockeNalog = new ArrayList<>(Collections.nCopies(stNalog, 0));
                        vpisna2tocke.put(vpisna, tockeNalog);
                    }
                    tockeNalog.set(iNaloga, tocke);   // (2)
                }
            } catch (FileNotFoundException ex) {
                System.err.printf("Datoteka %s ne obstaja.", datoteke[iNaloga]);
            }
        }
        return vpisna2tocke;
    }

    private static void izpisi(
            List<String> vpisne,
            Map<String, Student> vpisna2student,
            Map<String, List<Integer>> vpisna2tocke,
            int stNalog,
            String datoteka) {

        try (Writer writer = new FileWriter(datoteka)) {

            // zapi"semo glavo
            StringBuilder sbNaloge = new StringBuilder();
            for (int i = 0; i < stNalog; i++) {
                sbNaloge.append(String.format("N%d;", i + 1));
            }
            writer.write(String.format("VŠ;Ime;Priimek;%sSkupaj%n", sbNaloge));

            for (String vpisna: vpisne) {
                Student student = vpisna2student.get(vpisna);
                List<Integer> tocke = vpisna2tocke.get(vpisna);
                if (tocke == null) {
                    tocke = new ArrayList<>(Collections.nCopies(stNalog, 0));
                }

                String strTocke = tocke.toString();   // (1)
                strTocke = strTocke.substring(1, strTocke.length() - 1);
                strTocke = strTocke.replace(", ", ";");
                writer.write(String.format("%s;%s;%d%n",
                                           student.csv(), strTocke, vsota(tocke)));
            }

        } catch (IOException ex) {
            System.err.printf("Napaka pri pisanju v datoteko %s.", datoteka);
        }
    }

    private static int vsota(List<Integer> tocke) {
        if (tocke == null) {
            return 0;
        }
        int vsota = 0;
        for (int t: tocke) {
            vsota += t;
        }
        return vsota;
    }
}
