
public class Student {

    private String vpisna;
    private String ime;
    private String priimek;

    public Student(String vpisna, String ime, String priimek) {
        this.vpisna = vpisna;
        this.ime = ime;
        this.priimek = priimek;
    }

    public int primerjaj(Student drugi) {
        int c = this.priimek.compareTo(drugi.priimek);
        return (c != 0) ? (c) : (this.ime.compareTo(drugi.ime));
    }

    public String csv() {
        return String.format("%s;%s;%s", this.vpisna, this.ime, this.priimek);
    }
}
