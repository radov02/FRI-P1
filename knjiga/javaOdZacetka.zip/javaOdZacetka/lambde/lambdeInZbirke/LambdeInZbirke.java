
//
// Nekaj statičnih metod, ki uporabljajo objekte funkcijskih vmesnikov na
// zbirkah.
//

import java.util.*;
import java.util.function.*;

public class LambdeInZbirke {

    //
    // Vrne število elementov podane zbirke, ki izpolnjujejo podani pogoj.
    //
    public static <T> int prestej(Collection<T> zbirka, Predicate<T> pogoj) {
        int stevec = 0;
        for (T element: zbirka) {
            if (pogoj.test(element)) {
                stevec++;
            }
        }
        return stevec;
    }

    //
    // Za vsak element podane zbirke izvrši podano opravilo.
    //
    public static <T> void zaVsak(Collection<T> zbirka, Consumer<T> opravilo) {
        for (T element: zbirka) {
            opravilo.accept(element);
        }
    }

    //
    // Vrne rezultat izraza
    //
    // zacetek OP e_0 OP e_1 OP ... OP e_{n-1},
    //
    // pri čemer je OP podani operator, e_0, e_1, ..., e_{n-1} pa elementi
    // podane zbirke.
    //
    public static <T> T zdruzi(Collection<T> zbirka, 
                               BinaryOperator<T> operator, T zacetek) {
        T rezultat = zacetek;
        for (T element: zbirka) {
            rezultat = operator.apply(rezultat, element);
        }
        return rezultat;
    }

    //
    // Vrne slovar, v katerem se ključ /r/ preslika v seznam vseh elementov
    // podane zbirke, za katere funkcija vrne rezultat /r/.
    //
    public static <T, R> Map<R, List<T>> grupiraj(
            Collection<T> zbirka, Function<T, R> funkcija) {

        Map<R, List<T>> slovar = new HashMap<>();
        for (T element: zbirka) {
            R rezultat = funkcija.apply(element);
            List<T> elementiZaRezultat = slovar.get(rezultat);
            if (elementiZaRezultat == null) {
                elementiZaRezultat = new ArrayList<T>();
                slovar.put(rezultat, elementiZaRezultat);
            }
            elementiZaRezultat.add(element);
        }
        return slovar;
    }
}
