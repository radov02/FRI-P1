
//
// Razred za preizkus metod iz razreda LambdeInZbirke.
//

import java.util.*;

public class TestLambdeInZbirke {

    public static void main(String[] args) {
        List<Integer> stevila = List.of(20, 15, 32, 7, 19, 14, 23, 35);
        Set<String> imena = Set.of("Ana", "Branko", "Cvetka", "Denis");

        System.out.println("--- prestej ---");

        int stSodih = LambdeInZbirke.prestej(stevila, n -> n % 2 == 0);
        System.out.println(stSodih);

        int dolzina = 5;
        int stImen = LambdeInZbirke.prestej(imena, ime -> ime.length() == dolzina);
        System.out.println(stImen);
        System.out.println();

        System.out.println("--- zaVsak ---");

        LambdeInZbirke.zaVsak(stevila, n -> { System.out.println(n); });

        Map<String, Integer> ime2dolzina = new TreeMap<>();
        LambdeInZbirke.zaVsak(imena, ime -> { ime2dolzina.put(ime, ime.length()); });
        System.out.println(ime2dolzina);
        System.out.println();

        System.out.println("--- zdruzi ---");

        int vsota = LambdeInZbirke.zdruzi(stevila, (a, b) -> a + b, 0);
        System.out.println(vsota);

        String najdaljseIme = LambdeInZbirke.zdruzi(
                imena,
                (a, b) -> (a.length() > b.length() ? a : b),
                "");
        System.out.println(najdaljseIme);
        System.out.println();

        System.out.println("--- grupiraj ---");

        Map<Boolean, List<Integer>> sodost2stevila = LambdeInZbirke.grupiraj(
                stevila, n -> n % 2 == 0);
        System.out.println(sodost2stevila);

        Map<Integer, List<String>> dolzina2imena = LambdeInZbirke.grupiraj(
                imena, ime -> ime.length());
        System.out.println(dolzina2imena);
    }
}
