
//
// Razred, katerega objekti predstavljajo posamezne izredne študente.
//

public class IzredniStudent extends Student {
    private int solnina;    // dodatni atribut

    // konstruktor
    public IzredniStudent(String ip, String vpisna, int stroskiBivanja, int solnina) {
        super(ip, vpisna, stroskiBivanja);
        this.solnina = solnina;
    }

    // redefinirana metoda
    @Override
    public int stroski() {
        return super.stroski() + this.solnina;
    }
}
