
//
// Razred, katerega objekti predstavljajo posamezne študente.
//

public class Student {
    private String ip;           // ime in priimek
    private String vpisna;       // vpisna številka
    private int stroskiBivanja;  // mesečni stroški bivanja

    //
    // Inicializira objekt tako, da predstavlja študenta s podanim imenom in
    // priimkom (<ip>), vpisno številko (<vpisna>) ter mesečnimi stroški
    // bivanja (<stroskiBivanja>).
    //
    public Student(String ip, String vpisna, int stroskiBivanja) {
        this.ip = ip;
        this.vpisna = vpisna;
        this.stroskiBivanja = stroskiBivanja;
    }

    //
    // Vrne ime in priimek študenta /this/.
    //
    public String vrniIP() {
        return this.ip;
    }

    //
    // Vrne mesečne stroške za študenta /this/.
    //
    public int stroski() {
        return this.stroskiBivanja;
    }
}
