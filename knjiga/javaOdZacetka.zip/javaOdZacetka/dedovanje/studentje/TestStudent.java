
//
// Testni razred za hierarhijo študentov.
//

public class TestStudent {

    public static void main(String[] args) {
        Student ana = new Student("Ana Arko", "63190800", 500);
        System.out.println(ana.vrniIP());
        System.out.println(ana.stroski());

        IzredniStudent bojan = new IzredniStudent("Bojan Ban", "63190900", 600, 300);
        System.out.println(bojan.vrniIP());
        System.out.println(bojan.stroski());
        System.out.println();

        Student[] studentje = {
            new Student("Ana Arko", "63190800", 500),
            new IzredniStudent("Bojan Ban", "63190900", 600, 300),
            new IzredniStudent("Cvetka Cevc", "63191000", 400, 350),
            new Student("Denis Denk", "63191100", 450)
        };
        for (Student student: studentje) {
            System.out.printf("%s: %d%n", student.vrniIP(), student.stroski());
        }
    }
}
