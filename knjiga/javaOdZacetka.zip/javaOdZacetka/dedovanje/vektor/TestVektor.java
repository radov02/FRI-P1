
//
// Testni razred za razred Vektor.
//

public class TestVektor {

    public static void main(String[] args) {
        Vektor vektor = new Vektor();

        vektor.dodaj("Dober dan!");
        vektor.dodaj(new Cas(10, 35));
        vektor.dodaj(42);

        Object obj0 = vektor.vrni(0);
        Object obj1 = vektor.vrni(1);
        Object obj2 = vektor.vrni(2);
        System.out.println(obj0);
        System.out.println(obj1);
        System.out.println(obj2);

        String s = (String) obj0;
        Cas c = (Cas) obj1;
        Integer n = (Integer) obj2;

        System.out.println(c.vrniUro());
        // System.out.println(obj1.vrniUro());  // napaka pri prevajanju

        Vektor vektor2 = new Vektor();
        vektor2.dodaj("Dober dan!");
        // Integer n2 = (Integer) vektor.vrni(0);  // izjema tipa ClassCastException
    }
}
