
//
// Razred za predstavitev slovarja. Slovar je implementiran z zgoščeno tabelo.
//

public class Slovar {

    //
    // Objekt tega razreda predstavlja posamezno vozlišče v povezanih
    // seznamih.
    //
    private static class Vozlisce {
        Object kljuc;         // ključ
        Object vrednost;      // vrednost, ki pripada ključu
        Vozlisce naslednje;   // kazalec na naslednje vozlišče v povezanem seznamu

        Vozlisce(Object kljuc, Object vrednost, Vozlisce naslednje) {
            this.kljuc = kljuc;
            this.vrednost = vrednost;
            this.naslednje = naslednje;
        }
    }

    // privzeta velikost zgoščene tabele
    private static final int VELIKOST_TABELE = 97;

    // zgoščena tabela (tabela kazalcev na začetna vozlišča povezanih seznamov)
    private Vozlisce[] tabela;

    //
    // Inicializira novoustvarjeni objekt tako, da predstavlja slovar s
    // privzeto velikostjo zgoščene tabele.
    //
    public Slovar() {
        this(VELIKOST_TABELE);
    }

    //
    // Inicializira novoustvarjeni objekt tako, da predstavlja slovar s
    // podano velikostjo zgoščene tabele.
    //
    public Slovar(int velikostTabele) {
        this.tabela = new Vozlisce[velikostTabele];
    }

    //
    // Vrne vrednost, ki pripada podanemu ključu, oziroma /null/, če slovar
    // /this/ ne vsebuje podanega ključa.
    //
    public Object vrni(Object kljuc) {
        Vozlisce vozlisce = this.poisci(kljuc);
        if (vozlisce == null) {
            return null;
        }
        return vozlisce.vrednost;
    }

    //
    // Podani par ključ-vrednost shrani v slovar /this/.
    //
    public void shrani(Object kljuc, Object vrednost) {
        Vozlisce vozlisce = this.poisci(kljuc);
        if (vozlisce != null) {    // vozlišče že obstaja
            vozlisce.vrednost = vrednost;
        } else {      // vozlišče še ne obstaja
            int indeks = this.indeks(kljuc);
            vozlisce = new Vozlisce(kljuc, vrednost, this.tabela[indeks]);
            this.tabela[indeks] = vozlisce;
        }
    }

    //
    // Vrne kazalec na vozlišče, ki pripada podanemu ključu, oziroma /null/, če slovar
    // /this/ ne vsebuje podanega ključa.
    //
    private Vozlisce poisci(Object kljuc) {
        int indeks = this.indeks(kljuc);
        Vozlisce vozlisce = this.tabela[indeks];
        while (vozlisce != null && !vozlisce.kljuc.equals(kljuc)) {
            vozlisce = vozlisce.naslednje;
        }
        return vozlisce;
    }

    //
    // Vrne indeks celice zgoščene tabele, ki vsebuje kazalec na začetek
    // povezanega seznama, v katerem se nahaja podani ključ.
    //
    private int indeks(Object kljuc) {
        int n = this.tabela.length;
        return ((kljuc.hashCode() % n) + n) % n;
    }
}
