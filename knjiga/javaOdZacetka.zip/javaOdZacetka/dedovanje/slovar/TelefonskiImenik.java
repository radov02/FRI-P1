
//
// Program deluje kot preprost telefonski imenik. V zanki bere imena in če imena
// še ne pozna, prebere pripadajočo telefonsko številko, v nasprotnem primeru
// pa izpiše telefonsko številko, ki pripada prebranemu imenu.
//

import java.util.Scanner;

public class TelefonskiImenik {

    public static void main(String[] args) {
        Slovar ime2stevilka = new Slovar();
        Scanner sc = new Scanner(System.in);

        System.out.print("Vnesite ime: ");
        String ime = sc.nextLine();

        // dokler ne preberemo imena dolžine 0
        while (ime.length() > 0) {

            String stevilka = (String) ime2stevilka.vrni(ime);

            if (stevilka == null) {
                // prebranega imena še ne poznamo
                System.out.printf("Osebe %s ni v imeniku.%n", ime);
                System.out.print("Vnesite telefonsko številko: ");
                stevilka = sc.nextLine();
                ime2stevilka.shrani(ime, stevilka);

            } else {
                // prebrano ime že ne poznamo
                System.out.printf("Telefonska številka: %s%n", stevilka);
            }

            System.out.println();
            System.out.print("Vnesite ime: ");
            ime = sc.nextLine();
        }
    }
}
