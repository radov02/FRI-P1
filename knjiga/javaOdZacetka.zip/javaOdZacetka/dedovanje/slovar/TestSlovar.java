
//
// Testni razred za razred Slovar.
//

public class TestSlovar {

    public static void main(String[] args) {
        Slovar drzavaVSosede = new Slovar();
        drzavaVSosede.shrani("Slovenija", 4);
        drzavaVSosede.shrani("Avstrija", 8);
        drzavaVSosede.shrani("Češka", 4);
        drzavaVSosede.shrani("Francija", 8);
        drzavaVSosede.shrani("Italija", 6);
        drzavaVSosede.shrani("Slovaška", 5);
        drzavaVSosede.shrani("Švica", 5);

        System.out.println(drzavaVSosede.vrni("Avstrija"));
        System.out.println(drzavaVSosede.vrni("Nemčija"));

        drzavaVSosede.shrani("Avstrija", 9);
        System.out.println(drzavaVSosede.vrni("Avstrija"));
    }
}
