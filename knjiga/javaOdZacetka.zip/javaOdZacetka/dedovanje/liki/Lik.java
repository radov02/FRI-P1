
//
// Razred, ki služi kot izhodišče hierarhije likov.
//

public abstract class Lik {
    //
    // Vrne ploščino lika /this/.
    //
    public abstract double ploscina();

    //
    // Vrne obseg lika /this/.
    //
    public abstract double obseg();

    //
    // Vrne niz, ki podaja vrsto lika in podatke o liku /this/.
    //
    public String toString() {
        return String.format("%s [%s]", this.vrsta(), this.podatki());
    }

    //
    // Vrne vrsto lika /this/.
    //
    public abstract String vrsta();

    //
    // Vrne niz s podatki o liku /this/.
    //
    public abstract String podatki();
}
