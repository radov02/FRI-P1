
//
// Razred za preizkus hierarhije likov.
//

public class Glavni {

    public static void main(String[] args) {
        Lik[] liki = {
            new Krog(5.0),
            new Pravokotnik(5.0, 7.0),
            new Kvadrat(6.0),
            new Krog(6.0),
            new Pravokotnik(9.0, 3.0),
            new Krog(4.0),
            new Pravokotnik(8.0, 9.0),
            new Kvadrat(8.0)
        };

        System.out.println("izpisiPodatke");
        izpisiPodatke(liki);
        System.out.println();

        System.out.println("likZNajvecjoPloscino");
        Lik najLik = likZNajvecjoPloscino(liki);
        if (najLik != null) {
            System.out.println(najLik.toString());
        }
        System.out.println();

        System.out.println("pravokotnikZNajvecjoSirino");
        Pravokotnik najPravokotnik = pravokotnikZNajvecjoSirino(liki);
        if (najPravokotnik != null) {
            System.out.println(najPravokotnik.toString());
        }
        System.out.println();
    }

    //
    // Izpiše podatke o vseh likih v podani tabeli.
    //
    public static void izpisiPodatke(Lik[] liki) {
        for (Lik lik: liki) {
            System.out.printf("%s | p = %.1f, o = %.1f%n",
                    lik.toString(), lik.ploscina(), lik.obseg());
        }
    }

    //
    // Med liki v podani tabeli poišče in vrne tistega z največjo ploščino.
    // Če je tabela prazna, vrne /null/.
    //
    public static Lik likZNajvecjoPloscino(Lik[] liki) {
        Lik najLik = null;
        double najPloscina = 0.0;

        for (Lik lik: liki) {
            double ploscina = lik.ploscina();
            if (najLik == null || ploscina > najPloscina) {
                najPloscina = ploscina;
                najLik = lik;
            }
        }
        return najLik;
    }

    //
    // Med pravokotniki v podani tabeli poišče in vrne tistega z največjo
    // širino. Če tabela ne vsebuje nobenega pravokotnika, vrne /null/.
    //
    public static Pravokotnik pravokotnikZNajvecjoSirino(Lik[] liki) {
        Pravokotnik naj = null;
        for (Lik lik: liki) {
            if (lik instanceof Pravokotnik) {
                Pravokotnik p = (Pravokotnik) lik;
                if (naj == null || p.vrniSirino() > naj.vrniSirino()) {
                    naj = p;
                }
            }
        }
        return naj;
    }
}
