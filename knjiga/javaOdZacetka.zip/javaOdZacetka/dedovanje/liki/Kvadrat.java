
//
// Razred za predstavitev posameznih kvadratov.
//

public class Kvadrat extends Pravokotnik {
    public Kvadrat(double stranica) {
        super(stranica, stranica);
    }

    @Override
    public String vrsta() {
        return "kvadrat";
    }

    @Override
    public String podatki() {
        return String.format("stranica = %.1f", this.vrniSirino());
    }
}
