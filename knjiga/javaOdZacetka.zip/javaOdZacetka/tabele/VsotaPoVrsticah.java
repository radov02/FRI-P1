
//
// Program izdela tabelo z vsotami posameznih vrstic dvodimenzionalne tabele.
//

import java.util.Arrays;

public class VsotaPoVrsticah {

    public static void main(String[] args) {
        int[][] t = {
            {1, 2, 3, 4},
            {-5, 6, -10, 0},
            {13, 2, -8, 5}
        };

        int[] vsota = vsotaPoVrsticah(t);
        System.out.println(Arrays.toString(vsota));
    }

    //
    // Izdela in vrne tabelo, v kateri i-ti element podaja vsoto i-te vrstice
    // podane tabele.
    //
    public static int[] vsotaPoVrsticah(int[][] t) {
        int[] rezultat = new int[t.length];

        for (int i = 0; i < t.length; i++) {
            // izračunaj vsoto vrstice z indeksom i (vsoto tabele t[i]) ...
            int vsota = 0;
            for (int j = 0; j < t[i].length; j++) {
                vsota += t[i][j];
            }
            // ... in jo shrani v celico rezultat[i]
            rezultat[i] = vsota;
        }
        return rezultat;
    }
}
