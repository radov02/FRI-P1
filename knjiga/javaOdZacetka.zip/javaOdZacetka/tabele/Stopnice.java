
//
// Program izdela "stopničasto" tabelo.
//

import java.util.Arrays;

public class Stopnice {

    public static void main(String[] args) {
        int[][] t = new int[5][];
        for (int i = 0; i < t.length; i++) {
            t[i] = new int[i + 1];
        }
        System.out.println(Arrays.deepToString(t));
    }
}
