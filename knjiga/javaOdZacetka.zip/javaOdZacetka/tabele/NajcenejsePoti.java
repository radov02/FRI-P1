
//
// Za podani graf izračuna matriko najcenejših poti med posameznimi pari
// vozlišč. 
//

public class NajcenejsePoti {

    public static void main(String[] args) {
        // matrika sosednosti
        int[][] graf = {
            { 0,  1,  5, -1, -1, -1},
            {-1,  0,  2, 12, -1, -1},
            {-1, -1,  0,  8,  4, -1},
            {-1, -1, -1,  0, -1,  5},
            {-1,  2, -1,  3,  0,  9},
            {-1, -1, -1, -1,  6,  0}
        };
        int stVozlisc = graf.length;

        int[][] cene = najcenejsePoti(graf);

        for (int i = 0; i < stVozlisc; i++) {
            for (int j = 0; j < stVozlisc; j++) {
                System.out.printf("%3d", cene[i][j]);
            }
            System.out.println();
        }
    }

    //
    // Izdela in vrne matriko najcenejših poti med posameznimi pari vozlišč
    // podanega grafa.
    //
    public static int[][] najcenejsePoti(int[][] graf) {
        // matriko najcenejših poti izdelamo kot kopijo matrike sosednosti
        int stVozlisc = graf.length;
        int[][] cene = new int[stVozlisc][stVozlisc];
        for (int i = 0; i < stVozlisc; i++) {
            for (int j = 0; j < stVozlisc; j++) {
                cene[i][j] = graf[i][j];
            }
        }

        for (int k = 0; k < stVozlisc; k++) {
            for (int i = 0; i < stVozlisc; i++) {
                for (int j = 0; j < stVozlisc; j++) {
                    if (i != j) {
                        // posodobimo ceno poti od i do j
                        cene[i][j] = izberi(cene[i][j], cene[i][k], cene[k][j]);
                    }
                }
            }
        }
        return cene;
    }

    //
    // Vrne manjšo izmed vrednosti /trenutna/ in /odsek1/ + /odsek2/, pri
    // čemer upošteva, da negativna vrednost predstavlja neskončno.
    //
    public static int izberi(int trenutna, int odsek1, int odsek2) {
        if (odsek1 < 0 || odsek2 < 0) {
            return trenutna;
        }
        if (trenutna < 0) {
            return odsek1 + odsek2;
        }
        return Math.min(trenutna, odsek1 + odsek2);
    }
}
