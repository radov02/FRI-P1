
//
// Program prebere število /n/ in izpiše Fibonaccijevo število z indeksom /n/.
// Program uporablja rekurzijo z memoizacijo.
//

import java.util.Scanner;

public class FibonacciMemo {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        int[] memo = new int[n + 1];
        System.out.println(fib(n, memo));
    }

    //
    // Vrne Fibonaccijevo število z indeksom /n/, pri čemer za pomnjenje že
    // izračunanih rezultatov uporablja tabelo /memo/.
    //
    public static int fib(int n, int[] memo) {
        if (n <= 1) {
            return n;
        }

        if (memo[n] > 0) {
            // vrednost fib(n, memo) smo že izračunali
            return memo[n];
        }

        // vrednosti fib(n, memo) še nismo izračunali,
        // zato jo izračunamo in shranimo v tabelo
        memo[n] = fib(n - 2, memo) + fib(n - 1, memo);
        return memo[n];
    }
}
