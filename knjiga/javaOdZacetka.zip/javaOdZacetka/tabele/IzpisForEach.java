
//
// Sprehod po tabeli z zanko /for-each/.
//

public class IzpisForEach {

    public static void main(String[] args) {
        char[] samoglasniki = {'a', 'e', 'i', 'o', 'u'};
        for (char znak: samoglasniki) {
            System.out.println(znak);
        }
    }
}
