
//
// Dvojiško iskanje v urejeni tabeli.
//

public class Iskanje3 {

    public static void main(String[] args) {
        int[] t = {7, 10, 15, 21, 27, 30, 31, 34, 37, 39, 42, 50, 58, 61, 75};
        System.out.println(poisci(t, 7));
        System.out.println(poisci(t, 27));
        System.out.println(poisci(t, 42));
        System.out.println(poisci(t, 61));
        System.out.println(poisci(t, 75));
        System.out.println(poisci(t, 3));
        System.out.println(poisci(t, 35));
        System.out.println(poisci(t, 80));
    }

    //
    // Če podana naraščajoče urejena tabela /t/ vsebuje element /x/, vrne
    // njegov indeks, sicer pa vrne -1. Metoda uporablja dvojiško iskanje.
    //
    public static int poisci(int[] t, int x) {
        int lm = 0;
        int dm = t.length - 1;

        while (lm <= dm) {
            int s = (lm + dm) / 2;
            if (t[s] == x) {
                return s;
            }
            if (x > t[s]) {
                lm = s + 1;
            } else {
                dm = s - 1;
            }
        }
        return -1;
    }
}
