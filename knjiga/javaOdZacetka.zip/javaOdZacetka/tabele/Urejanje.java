
//
// Urejanje tabel.
//

import java.util.Arrays;

public class Urejanje {

    public static void main(String[] args) {
        int[] tabela = {80, 50, 75, 30, 45, 60};
        uredi(tabela);
        System.out.println(Arrays.toString(tabela));
    }

    //
    // Podano tabelo uredi z algoritmom navadnega vstavljanja.
    //
    public static void uredi(int[] t) {
        for (int i = 1; i < t.length; i++) {
            int el = t[i];
            int j = i - 1;
            while (j >= 0 && t[j] > el) {
                t[j + 1] = t[j];
                j--;
            }
            t[j + 1] = el;
        }
    }
}
