
//
// Program izdela tabelo z indeksi maksimumov posameznih stolpcev
// dvodimenzionalne tabele.
//

import java.util.Arrays;

public class ImaxPoStolpcih {

    public static void main(String[] args) {
        int[][] t = {
            {1, 2, 3, 4},
            {-5, 6, -10, 0},
            {13, 2, -8, 5}
        };

        int[] imax = imaxPoStolpcih(t);
        System.out.println(Arrays.toString(imax));
    }

    //
    // Izdela in vrne tabelo, v kateri i-ti element podaja indeks maksimuma
    // i-tega stolpca podane tabele.
    //
    public static int[] imaxPoStolpcih(int[][] t) {
        int stStolpcev = t[0].length;
        int[] rezultat = new int[stStolpcev];

        for (int j = 0; j < stStolpcev; j++) {
            // izračunaj indeks maksimuma v stolpcu z indeksom j ...
            int iMax = 0;
            for (int i = 1; i < t.length; i++) {
                if (t[i][j] > t[iMax][j]) {
                    iMax = i;
                }
            }
            // ... in ga shrani v rezultat[j]
            rezultat[j] = iMax;
        }
        return rezultat;
    }
}
