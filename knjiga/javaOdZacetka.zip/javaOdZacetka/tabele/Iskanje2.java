
//
// Izboljšano linearno iskanje v urejeni tabeli.
//

public class Iskanje2 {

    public static void main(String[] args) {
        int[] t = {7, 10, 15, 21, 27, 30, 31, 34, 37, 39, 42, 50, 58, 61, 75};
        System.out.println(poisci(t, 7));
        System.out.println(poisci(t, 27));
        System.out.println(poisci(t, 42));
        System.out.println(poisci(t, 61));
        System.out.println(poisci(t, 75));
        System.out.println(poisci(t, 3));
        System.out.println(poisci(t, 35));
        System.out.println(poisci(t, 80));
    }

    //
    // Če podana naraščajoče urejena tabela /t/ vsebuje element /x/, vrne
    // njegov indeks, sicer pa vrne -1. Metoda uporablja izboljšano linearno
    // iskanje.
    //
    public static int poisci(int[] t, int x) {
        int i = 0;
        while (i < t.length && t[i] < x) {
            i++;
        }
        return (i < t.length && t[i] == x) ? (i) : (-1);
    }
}
