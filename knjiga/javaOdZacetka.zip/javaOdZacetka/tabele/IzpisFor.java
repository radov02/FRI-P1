
//
// Sprehod po tabeli z zanko /for/.
//

public class IzpisFor {

    public static void main(String[] args) {
        char[] samoglasniki = {'a', 'e', 'i', 'o', 'u'};
        for (int i = 0; i < samoglasniki.length; i++) {
            System.out.printf("Element na indeksu %d: %c%n", i, samoglasniki[i]);
        }
    }
}
