
//
// Izpis elementov dvodimenzionalne tabele z zankama /for/ in /for-each/.
//

public class Izpis2D {

    public static void main(String[] args) {
        int[][] t = {
            {1, 2, 3, 4},
            {-5, 6, -10, 0},
            {13, 2, -8, 5}
        };

        izpisiPoIndeksih(t);
        System.out.println();
        izpisiPoElementih(t);
    }

    //
    // Podano tabelo izpiše s sprehodom po njenih indeksih (na obeh nivojih).
    //
    public static void izpisiPoIndeksih(int[][] t) {
        for (int i = 0; i < t.length; i++) {
            for (int j = 0; j < t[i].length; j++) {
                System.out.print(t[i][j] + " ");
            }
            System.out.println();
        }
    }

    //
    // Podano tabelo izpiše s sprehodom po njenih elementih (na obeh nivojih).
    //
    public static void izpisiPoElementih(int[][] t) {
        for (int[] vrstica: t) {
            for (int element: vrstica) {
                System.out.print(element + " ");
            }
            System.out.println();
        }
    }
}
