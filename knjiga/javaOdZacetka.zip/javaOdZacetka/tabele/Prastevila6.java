
//
// Program prebere število /n/ in izpiše vsa praštevila na intervalu [2, n].
// Program deluje po postopku Eratostenovega sita.
//

import java.util.Scanner;

public class Prastevila6 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        // pobrisano[i] == true <==> število i je pobrisano
        boolean[] pobrisano = new boolean[n + 1];
        int meja = (int) Math.round(Math.sqrt(n));

        int p = 2;
        while (p <= meja) {
            // pobriši števila 2 * p, 3 * p, 4 * p, ...
            for (int i = 2 * p; i <= n; i += p) {
                pobrisano[i] = true;
            }
            // poišči najmanjše nepobrisano število nad p
            do {
                p++;
            } while (p <= meja && pobrisano[p]);
        }

        // izpiši vsa nepobrisana števila (to so ravno praštevila)
        for (int i = 2; i <= n; i++) {
            if (!pobrisano[i]) {
                System.out.println(i);
            }
        }
    }
}
