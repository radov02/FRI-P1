
//
// Linearno iskanje v tabeli.
//

public class Iskanje1 {

    public static void main(String[] args) {
        int[] t = {7, 10, 15, 21, 27, 30, 31, 34, 37, 39, 42, 50, 58, 61, 75};
        System.out.println(poisci(t, 7));
        System.out.println(poisci(t, 27));
        System.out.println(poisci(t, 42));
        System.out.println(poisci(t, 61));
        System.out.println(poisci(t, 75));
        System.out.println(poisci(t, 3));
        System.out.println(poisci(t, 35));
        System.out.println(poisci(t, 80));
    }

    //
    // Če tabela /t/ vsebuje element /x/, vrne njegov indeks, sicer pa vrne
    // -1. Metoda uporablja navadno linearno iskanje.
    //
    public static int poisci(int[] t, int x) {
        for (int i = 0; i < t.length; i++) {
            if (t[i] == x) {
                return i;
            }
        }
        return -1;
    }
}
