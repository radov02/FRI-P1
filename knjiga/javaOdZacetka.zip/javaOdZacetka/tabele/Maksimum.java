
//
// Program izpiše največji element tabele in njegov indeks.
//

public class Maksimum {

    public static void main(String[] args) {
        int[] tabela = {70, 50, 60, 90, 30, 80};
        System.out.println(maksimum(tabela));
        System.out.println(indeksMaksimuma(tabela));
    }

    //
    // Vrne maksimalni element podane tabele.
    //
    public static int maksimum(int[] t) {
        int naj = t[0];
        for (int element: t) {
            if (element > naj) {
                naj = element;
            }
        }
        return naj;
    }

    //
    // Vrne indeks maksimalnega elementa podane tabele.
    //
    public static int indeksMaksimuma(int[] t) {
        int iNaj = 0;
        for (int i = 0; i < t.length; i++) {
            if (t[i] > t[iNaj]) {
                iNaj = i;
            }
        }
        return iNaj;
    }
}
