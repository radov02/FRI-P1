
//
// Navidez presenetljivo obnašanje pri medsebojnem prirejanju spremenljivk
// tabelaričnega tipa.
//

import java.util.Arrays;

public class KajIzpise {

    public static void main(String[] args) {
        int[] a = {1, 2, 3};
        System.out.println(Arrays.toString(a));

        int[] b = a;
        b[0] = 42;
        System.out.println(Arrays.toString(b));
        System.out.println(Arrays.toString(a));
    }
}
