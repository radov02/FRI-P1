
//
// Program izpiše vsoto elementov tabele.
//

public class Vsota {

    public static void main(String[] args) {
        System.out.println(vsota(new int[]{5, -2, 9, 3}));
    }

    //
    // Vrne vsoto elementov podane tabele.
    //
    public static int vsota(int[] t) {
        int vsota = 0;
        for (int element: t) {
            vsota += element;
        }
        return vsota;
    }
}
