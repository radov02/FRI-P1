
//
// Primer rekurzivne metode.
//

import java.util.Scanner;

public class Rekurzija {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        f(n);
    }

    public static void f(int n) {
        if (n > 0) {
            f(n - 1);
            System.out.println(n);
        }
    }
}
