
//
// Program prebere število /n/ in nariše "križ" s krakom dolžine /n/.
//

import java.util.Scanner;

public class Kriz3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        navpicniKrak(n);

        for (int i = 1; i <= 2 * n + 1; i++) {
            System.out.print("+");
        }
        System.out.println();

        navpicniKrak(n);
    }

    //
    // Nariše navpični krak višine /visina/.
    //
    public static void navpicniKrak(int visina) {
        for (int i = 1; i <= visina; i++) {
            for (int j = 1; j <= visina; j++) {
                System.out.print(" ");
            }
            System.out.println("+");
        }
    }
}
