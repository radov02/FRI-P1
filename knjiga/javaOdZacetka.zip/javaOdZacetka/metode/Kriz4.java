
//
// Enako kot Kriz3, le da si pomagamo še z metodama /sredinskaLinija/ in /zaporedje/.
//

import java.util.Scanner;

public class Kriz4 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        navpicniKrak(n);
        sredinskaLinija(n);
        navpicniKrak(n);
    }

    //
    // Nariše navpični krak višine /visina/.
    //
    public static void navpicniKrak(int visina) {
        for (int i = 1; i <= visina; i++) {
            zaporedje(visina, ' ', false);
            zaporedje(1, '+', true);
        }
    }

    //
    // Nariše sredinsko linijo.
    //
    public static void sredinskaLinija(int n) {
        zaporedje(2 * n + 1, '+', true);
    }

    //
    // Nariše zaporedje /n/ znakov /znak/. Če velja /prelom/, doda še prelom
    // vrstice.
    //
    public static void zaporedje(int n, char znak, boolean prelom) {
        for (int i = 1; i <= n; i++) {
            System.out.print(znak);
        }
        if (prelom) {
            System.out.println();
        }
    }
}
