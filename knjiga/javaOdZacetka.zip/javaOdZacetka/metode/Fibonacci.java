
//
// Program prebere število /n/ in izpiše Fibonaccijevo število z indeksom /n/.
//

import java.util.Scanner;

public class Fibonacci {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int stevilo = sc.nextInt();
        System.out.println(fib(stevilo));
    }

    //
    // Vrne Fibonaccijevo število z indeksom /n/.
    //
    public static int fib(int n) {
        if (n <= 1) {
            return n;
        }
        return fib(n - 2) + fib(n - 1);
    }
}
