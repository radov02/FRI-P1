
//
// Prebere število /n/ in za vsako število z intervala [1, n] preveri, ali
// obstaja število, ki z njim tvori prijateljski par. Če takšno število
// obstaja, ga izpiše.
//

import java.util.Scanner;

public class Prijatelji {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        for (int a = 1; a <= n; a++) {
            int b = vsotaDeliteljev(a);
            if (a != b && vsotaDeliteljev(b) == a) {
                System.out.printf("%d -> %d%n", a, b);
            }
        }
    }

    //
    // Vrne vsoto deliteljev podanega števila, pri čemer števila samega ne
    // vključi v vsoto.
    //
    public static int vsotaDeliteljev(int stevilo) {
        int vsota = 0;
        for (int d = 1; d < stevilo; d++) {
            if (stevilo % d == 0) {
                vsota += d;
            }
        }
        return vsota;
    }
}
