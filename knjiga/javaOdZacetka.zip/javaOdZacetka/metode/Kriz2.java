
//
// Program nariše "križ" s krakom dolžine 4.
// Različica z metodo navpicniKrak.
//

public class Kriz2 {

    public static void main(String[] args) {
        navpicniKrak();   // klic metode navpicniKrak

        for (int i = 1; i <= 9; i++) {
            System.out.print("+");
        }
        System.out.println();

        navpicniKrak();   // klic metode navpicniKrak
    }

    //
    // Nariše navpični krak.
    //
    public static void navpicniKrak() {
        for (int i = 1; i <= 4; i++) {
            for (int j = 1; j <= 4; j++) {
                System.out.print(" ");
            }
            System.out.println("+");
        }
    }
}
