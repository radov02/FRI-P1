
//
// Enako kot krmilniKonstrukti/Prastevila4.java, le da praštevilskost tekočega
// števila preverimo z metodo.
//

import java.util.Scanner;

public class Prastevila5 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        System.out.println(2);
        for (int kandidat = 3; kandidat <= n; kandidat += 2) {
            if (jePrastevilo(kandidat)) {
                System.out.println(kandidat);
            }
        }
    }

    //
    // Vrne /true/ natanko v primeru, če je podano liho število praštevilo.
    //
    public static boolean jePrastevilo(int lihoStevilo) {
        int meja = (int) Math.round(Math.sqrt(lihoStevilo));
        for (int d = 3; d <= meja; d += 2) {
            if (lihoStevilo % d == 0) {
                return false;
            }
        }
        return true;
    }
}
