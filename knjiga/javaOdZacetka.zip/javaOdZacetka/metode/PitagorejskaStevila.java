
//
// Enako kot krmilniKonstrukti/PitagorejskaStevila.java, le da
// "pitagorejskost" števila preverimo z metodo.
//

import java.util.Scanner;

public class PitagorejskaStevila {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int meja = sc.nextInt();

        int stPitagorejskih = 0;
        for (int c = 1; c <= meja; c++) {
            if (jePitagorejsko(c)) {
                stPitagorejskih++;
            }
        }
        System.out.println(stPitagorejskih);
    }

    //
    // Vrne true natanko v primeru, če lahko podano število /c/ zapišemo kot
    // c^2 = a^2 + b^2, kjer sta /a/ in /b/ pozitivni celi števili.
    //
    public static boolean jePitagorejsko(int c) {
        for (int a = 1; a < c - 1; a++) {
            for (int b = a + 1; b < c; b++) {
                if (c * c == a * a + b * b) {
                    return true;
                }
            }
        }
        return false;
    }
}
