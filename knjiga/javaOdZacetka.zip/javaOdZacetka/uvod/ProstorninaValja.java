
import java.util.Scanner;

public class ProstorninaValja {

    public static void main(String[] args) {
        // preberi podatke o valju
        Scanner sc = new Scanner(System.in);
        double r = sc.nextDouble();   // polmer
        double h = sc.nextDouble();   // višina

        // izpiši prostornino valja
        System.out.println(prostornina(r, h));
    }

    /* 
    Vrne prostornino valja s podanim polmerom osnovne ploskve in višino.
    polmer -- polmer osnovne ploskve valja
    visina -- višina valja
    */
    public static double prostornina(double polmer, double visina) {
        return Math.PI * polmer * polmer * visina;
    }
}
