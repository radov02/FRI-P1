public class MojPrvi {
    public static void main(String[] args) {
        System.out.println("Pozdravljen, svet!");
    }
}
