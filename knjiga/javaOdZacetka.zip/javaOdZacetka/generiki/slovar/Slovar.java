
//
// Generični razred za predstavitev slovarja. Slovar je implementiran z
// zgoščeno tabelo.
//

public class Slovar<K, V> {

    //
    // Objekt tega razreda predstavlja posamezno vozlišče v povezanih
    // seznamih.
    //
    private static class Vozlisce<K, V> {
        K kljuc;
        V vrednost;
        Vozlisce<K, V> naslednje;

        Vozlisce(K kljuc, V vrednost, Vozlisce<K, V> naslednje) {
            this.kljuc = kljuc;
            this.vrednost = vrednost;
            this.naslednje = naslednje;
        }
    }

    // privzeta velikost zgoščene tabele
    private static final int VELIKOST_TABELE = 97;

    // zgoščena tabela (tabela kazalcev na začetna vozlišča povezanih seznamov)
    private Vozlisce<K, V>[] podatki;

    //
    // Inicializira novoustvarjeni objekt tako, da predstavlja slovar s
    // privzeto velikostjo zgoščene tabele.
    //
    public Slovar() {
        this(VELIKOST_TABELE);
    }

    //
    // Inicializira novoustvarjeni objekt tako, da predstavlja slovar s
    // podano velikostjo zgoščene tabele.
    //
    @SuppressWarnings("unchecked")
    public Slovar(int velTab) {
        this.podatki = (Vozlisce<K, V>[]) new Vozlisce<?, ?>[velTab];
    }

    //
    // Vrne vrednost, ki pripada podanemu ključu, oziroma /null/, če slovar
    // /this/ ne vsebuje podanega ključa.
    //
    public V vrni(K kljuc) {
        Vozlisce<K, V> vozlisce = this.poisci(kljuc);
        if (vozlisce == null) {
            return null;
        }
        return vozlisce.vrednost;
    }

    //
    // Podani par ključ-vrednost shrani v slovar /this/.
    //
    public void shrani(K kljuc, V vrednost) {
        Vozlisce<K, V> vozlisce = this.poisci(kljuc);
        if (vozlisce != null) {
            vozlisce.vrednost = vrednost;
        } else {
            int indeks = this.indeks(kljuc);
            vozlisce = new Vozlisce<>(kljuc, vrednost,
                                      this.podatki[indeks]);
            this.podatki[indeks] = vozlisce;
        }
    }

    //
    // Vrne kazalec na vozlišče, ki pripada podanemu ključu, oziroma /null/, če slovar
    // /this/ ne vsebuje podanega ključa.
    //
    private Vozlisce<K, V> poisci(K kljuc) {
        int indeks = this.indeks(kljuc);
        Vozlisce<K, V> vozlisce = this.podatki[indeks];
        while (vozlisce != null && !vozlisce.kljuc.equals(kljuc)) {
            vozlisce = vozlisce.naslednje;
        }
        return vozlisce;
    }

    //
    // Vrne indeks celice zgoščene tabele, ki vsebuje kazalec na začetek
    // povezanega seznama, v katerem se nahaja podani ključ.
    //
    private int indeks(K kljuc) {
        int n = this.podatki.length;
        return ((kljuc.hashCode() % n) + n) % n;
    }
}
