
//
// Testni razred za razred Slovar.
//

public class TestSlovar {

    public static void main(String[] args) {
        Slovar<String, Integer> s2i = new Slovar<>();
        s2i.shrani("ena", 1);
        s2i.shrani("dve", 2);
        s2i.shrani("tri", 3);
        // s2i.shrani(4, "stiri");   // napaka pri prevajanju

        int n = s2i.vrni("tri");
        System.out.println(n);

        // String s = s2i.vrni("dve");  // napaka pri prevajanju
        // int m = s2i.vrni(2);         // napaka pri prevajanju

        Slovar<Cas, String> urnik = new Slovar<>();
        urnik.shrani(new Cas(6, 30), "zajtrk");
        urnik.shrani(new Cas(12, 30), "kosilo");
        urnik.shrani(new Cas(19, 0), "večerja");

        String obrok = urnik.vrni(new Cas(12, 30));
        System.out.println(obrok);
    }
}
