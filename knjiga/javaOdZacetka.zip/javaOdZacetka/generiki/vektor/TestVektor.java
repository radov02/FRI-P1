
//
// Testni razred za razred Vektor.
//

public class TestVektor {

    public static void main(String[] args) {
        Vektor<String> besede = new Vektor<>();
        besede.dodaj("danes");
        besede.dodaj("je");
        besede.dodaj("lep");
        besede.dodaj("dan");
        // besede.dodaj(42);  // napaka pri prevajanju

        Vektor<Integer> stevila = new Vektor<>();
        stevila.dodaj(10);
        stevila.dodaj(20);
        stevila.dodaj(30);
        // stevila.dodaj("abc");  // napaka pri prevajanju

        String s = besede.vrni(1);
        Integer n = stevila.vrni(2);
        System.out.println(s);
        System.out.println(n);

        // Integer m = besede.vrni(2);  // napaka pri prevajanju
        // String t = stevila.vrni(0);  // napaka pri prevajanju
    }
}
