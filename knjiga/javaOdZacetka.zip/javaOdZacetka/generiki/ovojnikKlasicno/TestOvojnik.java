
//
// Razred za preizkus razreda Ovojnik.
//

public class TestOvojnik {

    public static void main(String[] args) {
        Ovojnik p = new Ovojnik("dober dan");
        Ovojnik q = new Ovojnik(42);
        Ovojnik r = new Ovojnik(new Cas(10, 35));

        String s = (String) p.vrni();
        Integer n = (Integer) q.vrni();
        Cas c = (Cas) r.vrni();

        System.out.println(s);
        System.out.println(n);
        System.out.println(c);

        // Integer n1 = (Integer) p.vrni();  // ClassCastException
    }
}
