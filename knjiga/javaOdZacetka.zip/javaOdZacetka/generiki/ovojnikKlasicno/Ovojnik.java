
//
// Preprost razred za hrambo objekta poljubnega tipa.
//

public class Ovojnik {
    private Object a;

    public Ovojnik(Object a) {
        this.a = a;
    }

    //
    // Vrne objekt, ki ga hrani ovojnik /this/.
    //
    public Object vrni() {
        return this.a;
    }
}
