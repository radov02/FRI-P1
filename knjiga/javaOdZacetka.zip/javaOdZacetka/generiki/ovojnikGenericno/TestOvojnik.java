
//
// Razred za preizkus generičnega razreda Ovojnik.
//

public class TestOvojnik {

    public static void main(String[] args) {
        Ovojnik<String> p = new Ovojnik<String>("dober dan");
        Ovojnik<Integer> q = new Ovojnik<Integer>(42);
        Ovojnik<Cas> r = new Ovojnik<Cas>(new Cas(10, 35));

        String s = p.vrni();
        Integer n = q.vrni();
        Cas c = r.vrni();
        // Integer n1 = p.vrni();  // napaka pri prevajanju

        System.out.println(s);
        System.out.println(n);
        System.out.println(c);
        System.out.println();

        System.out.println("enakaVsebina:");
        Ovojnik<String> oa = new Ovojnik<>("abc");
        Ovojnik<String> ob = new Ovojnik<>("de");
        Ovojnik<String> oc = new Ovojnik<>("abc");
        Ovojnik<Integer> od = new Ovojnik<>(123);

        System.out.println(enakaVsebina(oa, ob));
        System.out.println(enakaVsebina(oa, oc));
        // System.out.println(enakaVsebina(oa, od));  // napaka pri prevajanju
        System.out.println(TestOvojnik.<String>enakaVsebina(oa, ob));
    }

    //
    // Vrne /true/ natanko v primeru, če sta objekta, ki ju hranita podana
    // ovojnika, med seboj enaka (equals).
    //
    public static <T> boolean enakaVsebina(Ovojnik<T> p, Ovojnik<T> q) {
        return p.vrni().equals(q.vrni());
    }
}
