
public class TestStevilskiOvojnik {

    public static void main(String[] args) {
        StevilskiOvojnik<Integer> a = new StevilskiOvojnik<>(10);
        StevilskiOvojnik<Integer> b = new StevilskiOvojnik<>(15);
        StevilskiOvojnik<Double> c = new StevilskiOvojnik<>(5.0);

        System.out.println(a.jeVecjiKot(b));
        System.out.println(a.jeVecjiKot(c));
    }
}
