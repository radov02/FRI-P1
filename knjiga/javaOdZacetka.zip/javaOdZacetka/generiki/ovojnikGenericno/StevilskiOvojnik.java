
//
// Razred za hrambo objekta podtipa tipa Number.
//

public class StevilskiOvojnik<T extends Number> {
    private T a;

    public StevilskiOvojnik(T a) {
        this.a = a;
    }

    //
    // Vrne objekt, ki ga hrani ovojnik /this/.
    //
    public T vrni() {
        return this.a;
    }

    //
    // Vrne /true/ natanko v primeru, če je število, ki ga (posredno) hrani
    // objekt /this/, večje od števila, ki ga (posredno) hrani objekt /drugi/.
    //
    public <U extends Number> boolean jeVecjiKot(StevilskiOvojnik<U> drugi) {
        return this.a.doubleValue() > drugi.a.doubleValue();
    }
}
