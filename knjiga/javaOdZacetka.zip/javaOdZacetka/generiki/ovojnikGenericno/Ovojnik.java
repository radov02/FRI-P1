
//
// Generični razred za hrambo objekta poljubnega tipa.
//

public class Ovojnik<T> {
    private T a;

    public Ovojnik(T a) {   // tukaj ne pišemo Ovojnik<T>
        this.a = a;
    }

    //
    // Vrne objekt, ki ga hrani ovojnik /this/.
    //
    public T vrni() {
        return this.a;
    }
}
