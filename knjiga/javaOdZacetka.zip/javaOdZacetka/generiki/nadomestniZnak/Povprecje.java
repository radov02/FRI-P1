
//
// Primer uporabe nadomestnega znaka.
//

import java.util.*;

public class Povprecje {

    public static void main(String[] args) {
        Vektor<Number> vn = new Vektor<>();
        vn.dodaj(1);
        vn.dodaj(2);
        vn.dodaj(3);
        vn.dodaj(4);
        System.out.println(povprecje(vn));

        Vektor<Integer> vi = new Vektor<>();
        vi.dodaj(1);
        vi.dodaj(2);
        vi.dodaj(3);
        vi.dodaj(4);
        // System.out.println(povprecje(vi)); // se ne prevede
        System.out.println(povprecje2(vi));   // OK
    }

    //
    // Vrne povprečje elementov vektorja tipa Vektor<Number>.
    //
    public static double povprecje(Vektor<Number> vektor) {
        double vsota = 0;
        int stElementov = vektor.steviloElementov();
        for (int i = 0; i < stElementov; i++) {
            vsota += vektor.vrni(i).doubleValue();
        }
        return vsota / stElementov;
    }

    //
    // Vrne povprečje elementov vektorja tipa Vektor<R>, kjer je R tip Number
    // ali poljuben podtip tipa Number.
    //
    public static double povprecje2(Vektor<? extends Number> vektor) {
        double vsota = 0;
        int stElementov = vektor.steviloElementov();
        for (int i = 0; i < stElementov; i++) {
            vsota += vektor.vrni(i).doubleValue();
        }
        return vsota / stElementov;
    }
}
