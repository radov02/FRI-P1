
//
// Testni razred za razred VektorInt.
//

public class TestVektorInt {

    public static void main(String[] args) {
        VektorInt vektor = new VektorInt(3);

        System.out.println("--- dodaj ---");
        for (int stevilo = 10; stevilo <= 100; stevilo += 10) {
            vektor.dodaj(stevilo);
        }
        System.out.println(vektor.toString());
        System.out.println();

        System.out.println("--- vstavi ---");
        vektor.vstavi(2, 25);
        System.out.println(vektor.toString());
        System.out.println();

        System.out.println("--- odstrani ---");
        vektor.odstrani(4);
        System.out.println(vektor.toString());
        System.out.println();

        System.out.println("--- vrni ---");
        System.out.println(vektor.vrni(4));
        System.out.println();

        System.out.println("--- nastavi ---");
        vektor.nastavi(3, 35);
        System.out.println(vektor.toString());
    }
}
