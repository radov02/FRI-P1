
//
// Testni razred za razred VektorString.
//

public class TestVektorString {

    public static void main(String[] args) {
        VektorString vektor = new VektorString(3);

        System.out.println("--- dodaj --");
        vektor.dodaj("Ana");
        vektor.dodaj("Bojan");
        vektor.dodaj("Cvetka");
        vektor.dodaj("Drago");
        vektor.dodaj("Eva");
        System.out.println(vektor.toString());
        System.out.println();

        System.out.println("--- vstavi ---");
        vektor.vstavi(2, "Branko");
        System.out.println(vektor.toString());
        System.out.println();

        System.out.println("--- odstrani ---");
        vektor.odstrani(4);
        System.out.println(vektor.toString());
        System.out.println();

        System.out.println("--- vrni ---");
        System.out.println(vektor.vrni(4));
        System.out.println();

        System.out.println("--- nastavi ---");
        vektor.nastavi(3, "Cilka");
        System.out.println(vektor.toString());
    }
}
