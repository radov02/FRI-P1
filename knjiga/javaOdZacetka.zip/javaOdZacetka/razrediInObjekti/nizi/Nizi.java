
//
// Delo z nizi.
//

public class Nizi {

    public static void main(String[] args) {

        System.out.println("+ / +=");
        String a = "programiranje";
        String b = "v javi";
        String c = a + " " + b;
        System.out.println(c);
        c += " SE";
        System.out.println(c);
        System.out.println();

        System.out.println("== / equals");
        a = "programiranje";
        b = a;
        c = new String("programiranje");
        System.out.println(a == b);
        System.out.println(a == c);
        System.out.println(a.equals(b));
        System.out.println(a.equals(c));
        System.out.println();

        String niz = "programiranje";

        // pridobi znak na podanem indeksu
        System.out.println("charAt");
        System.out.println(niz.charAt(3));
        System.out.println();

        // leksikografsko primerjaj niza
        System.out.println("compareTo");
        System.out.println(niz.compareTo("java"));
        System.out.println();

        // preveri, ali se niz prične oz. konča z določenim nizom
        System.out.println("startsWith / endsWith");
        System.out.println(niz.startsWith("prog"));
        System.out.println(niz.endsWith("ranje"));
        System.out.println();

        // poišči znak ali podniz
        System.out.println("indexOf");
        System.out.println(niz.indexOf('g'));
        System.out.println(niz.indexOf("mira"));
        System.out.println();

        // vrni dolžino oz. preveri praznost
        System.out.println("length / isEmpty");
        System.out.println(niz.length());
        System.out.println(niz.isEmpty());
        System.out.println();

        // pridobi podniz med podanima indeksoma
        System.out.println("substring");
        System.out.println(niz.substring(2, 7));
        System.out.println();

        // zamenjaj podniz
        System.out.println("replace");
        System.out.println(niz.replace("gramir", "slavlj"));
        System.out.println();

        // odstrani začetne in končne presledke
        System.out.println("strip");
        System.out.println("   abc  ".strip());
        System.out.println();

        // razbij na komponente, ločene s poljubnim zaporedjem presledkov,
        // tabulatorjev in prelomov vrstice (\\s predstavlja presledek, 
        // tabulator ali prelom vrstice, + pa pomeni "eden ali več")
        System.out.println("split");
        String[] besede = "danes je lep dan".split("\\s+");
        for (String beseda: besede) {
            System.out.println(beseda);
        }
        System.out.println();

        // to pa že poznamo ...
        System.out.println("format");
        int prvo = 3;
        int drugo = 4;
        System.out.println(String.format("%d + %d = %d", prvo, drugo, prvo + drugo));
        System.out.println();
    }
}
