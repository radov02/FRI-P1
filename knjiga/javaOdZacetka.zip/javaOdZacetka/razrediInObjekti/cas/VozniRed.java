
//
// Primer uporabe razreda Cas: izpis voznega reda.
//

import java.util.Scanner;

public class VozniRed {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int uraZac = sc.nextInt();
        int minutaZac = sc.nextInt();
        int uraKon = sc.nextInt();
        int minutaKon = sc.nextInt();
        int interval = sc.nextInt();

        // tekoči čas
        Cas cas = new Cas(uraZac, minutaZac);

        // končni čas
        Cas casKon = new Cas(uraKon, minutaKon);

        // tekočemu času prištevamo interval, dokler ne presežemo končnega
        // časa
        while (cas.jeManjsiAliEnak(casKon)) {
            System.out.println(cas);
            cas = cas.plus(0, interval);
        }
    }
}
