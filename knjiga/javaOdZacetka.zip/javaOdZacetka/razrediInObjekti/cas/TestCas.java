
//
// Testni razred za razred Cas.
//

public class TestCas {

    public static void main(String[] args) {
        System.out.println("pristejStatic");
        Cas trenutek = new Cas(10, 35);
        Cas.pristejStatic(trenutek, 2, 50);
        System.out.println(trenutek.vrniUro());
        System.out.println(trenutek.vrniMinuto());
        System.out.println();

        System.out.println("pristej");
        trenutek = new Cas(10, 35);
        trenutek.pristej(2, 50);
        System.out.println(trenutek.vrniUro());
        System.out.println(trenutek.vrniMinuto());
        System.out.println();

        System.out.println("nastaviUro");
        trenutek = new Cas(10, 35);
        trenutek.nastaviUro(17);
        System.out.println(trenutek.vrniUro());
        System.out.println(trenutek.vrniMinuto());
        System.out.println();

        System.out.println("plus");
        trenutek = new Cas(10, 35);
        Cas kasneje = trenutek.plus(2, 50);
        System.out.println(kasneje.vrniUro());
        System.out.println(kasneje.vrniMinuto());
        System.out.println(trenutek.vrniUro());
        System.out.println(trenutek.vrniMinuto());
        System.out.println();

        System.out.println("izpisi");
        trenutek = new Cas(10, 35);
        trenutek.izpisi();
        System.out.println();
        System.out.println();

        System.out.println("toString");
        trenutek = new Cas(10, 35);
        System.out.println(trenutek.toString());
        Cas kosilo = new Cas(12, 0);
        String porocilo = String.format(
            "Ob %s smo pojedli kosilo, ob %s pa smo šli teč.",
            kosilo.toString(), kosilo.plus(3, 30).toString()
        );
        System.out.println(porocilo);
        System.out.println();

        System.out.println("jeEnakKot_poskus / jeEnakKot");
        Cas a = new Cas(10, 35);
        Cas b = a;
        Cas c = new Cas(10, 35);
        Cas d = new Cas(8, 40);
        System.out.println(a.jeEnakKot_poskus(b));
        System.out.println(a.jeEnakKot(b));
        System.out.println(a.jeEnakKot_poskus(c));
        System.out.println(a.jeEnakKot(c));
        System.out.println(a.jeEnakKot_poskus(d));
        System.out.println(a.jeEnakKot(d));
        System.out.println();

        System.out.println("razlikaVMin");
        System.out.println(new Cas(10, 35).razlikaVMin(new Cas(13, 10)));
        System.out.println();

        System.out.println("jeManjsiOd / jeManjsiAliEnak");
        Cas predavanja = new Cas(8, 15);
        Cas vaje = new Cas(11, 15);
        Cas sestanek = new Cas(11, 15);
        System.out.println(predavanja.jeManjsiOd(vaje));
        System.out.println(vaje.jeManjsiOd(sestanek));
        System.out.println(vaje.jeManjsiAliEnak(sestanek));
        System.out.println();

        System.out.println("nastaviZapis12");
        a = new Cas(10, 35);
        b = new Cas(15, 20);
        Cas.nastaviZapis12(true);
        System.out.printf("%s, %s%n", a, b);
        Cas.nastaviZapis12(false);
        System.out.printf("%s, %s%n", a, b);
        System.out.println();

        System.out.println("konstruktor z enim parametrom");
        Cas obUri = new Cas(16);
        System.out.println(obUri.toString());
    }
}
