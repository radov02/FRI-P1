
//
// Izhodiščna različica razreda za predstavitev ulomkov.
// (Zasluži si takojšen popravek: atributa naj bosta privatna.)
//

public class Ulomek {
    int stevec;
    int imenovalec;
}
