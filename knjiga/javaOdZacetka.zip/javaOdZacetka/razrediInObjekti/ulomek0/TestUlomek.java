
//
// Testni razred za izhodiščno različico razreda Ulomek.
//

public class TestUlomek {

    public static void main(String[] args) {
        Ulomek a = new Ulomek();
        a.stevec = 3;
        a.imenovalec = 5;
        System.out.printf("%d/%d%n", a.stevec, a.imenovalec);

        Ulomek b = new Ulomek();
        b.stevec = 8;
        b.imenovalec = 2;
        System.out.printf("%d/%d%n", b.stevec, b.imenovalec);
    }
}
