
//
// Testni razred za razred Slovar.
//

import java.util.*;

public class TestSlovar {

    public static void main(String[] args) {
        Slovar<String, Integer> drzavaVSosede = new Slovar<>();
        drzavaVSosede.shrani("Slovenija", 4);
        drzavaVSosede.shrani("Avstrija", 8);
        drzavaVSosede.shrani("Češka", 4);
        drzavaVSosede.shrani("Francija", 8);
        drzavaVSosede.shrani("Italija", 6);
        drzavaVSosede.shrani("Slovaška", 5);
        drzavaVSosede.shrani("Švica", 5);

        // sprehod z eksplicitnimi klici iteratorjevih metod
        Iterator<String> it = drzavaVSosede.iterator();
        while (it.hasNext()) {
            String drzava = it.next();
            int stSosed = drzavaVSosede.vrni(drzava);
            System.out.printf("%s -> %d%n", drzava, stSosed);
        }
        System.out.println();

        // sprehod z zanko for-each
        for (String drzava: drzavaVSosede) {
            int stSosed = drzavaVSosede.vrni(drzava);
            System.out.printf("%s -> %d%n", drzava, stSosed);
        }
    }
}
