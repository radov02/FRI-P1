
//
// Generični razred za predstavitev slovarja. Slovar je implementiran z
// zgoščeno tabelo.
//

import java.util.*;

public class Slovar<K, V> implements Iterable<K> {

    //
    // Objekt tega razreda predstavlja posamezno vozlišče v povezanih
    // seznamih.
    //
    private static class Vozlisce<K, V> {
        K kljuc;
        V vrednost;
        Vozlisce<K, V> naslednje;

        Vozlisce(K kljuc, V vrednost, Vozlisce<K, V> naslednje) {
            this.kljuc = kljuc;
            this.vrednost = vrednost;
            this.naslednje = naslednje;
        }
    }

    // privzeta velikost zgoščene tabele
    private static final int VELIKOST_TABELE = 97;

    // zgoščena tabela (tabela kazalcev na začetna vozlišča povezanih seznamov)
    private Vozlisce<K, V>[] podatki;

    // število parov ključ-vrednost v slovarju /this/ (= število ključev)
    private int stParov;

    //
    // Inicializira novoustvarjeni objekt tako, da predstavlja slovar s
    // privzeto velikostjo zgoščene tabele.
    //
    public Slovar() {
        this(VELIKOST_TABELE);
    }

    //
    // Inicializira novoustvarjeni objekt tako, da predstavlja slovar s
    // podano velikostjo zgoščene tabele.
    //
    @SuppressWarnings("unchecked")
    public Slovar(int velTab) {
        this.podatki = (Vozlisce<K, V>[]) new Vozlisce<?, ?>[velTab];
        this.stParov = 0;
    }

    //
    // Vrne vrednost, ki pripada podanemu ključu, oziroma /null/, če slovar
    // /this/ ne vsebuje podanega ključa.
    //
    public V vrni(K kljuc) {
        Vozlisce<K, V> vozlisce = this.poisci(kljuc);
        if (vozlisce == null) {
            return null;
        }
        return vozlisce.vrednost;
    }

    //
    // Podani par ključ-vrednost shrani v slovar /this/.
    //
    public void shrani(K kljuc, V vrednost) {
        Vozlisce<K, V> vozlisce = this.poisci(kljuc);
        if (vozlisce != null) {
            vozlisce.vrednost = vrednost;
        } else {
            int indeks = this.indeks(kljuc);
            vozlisce = new Vozlisce<>(kljuc, vrednost,
                                      this.podatki[indeks]);
            this.podatki[indeks] = vozlisce;
            this.stParov++;
        }
    }

    //
    // Vrne kazalec na vozlišče, ki pripada podanemu ključu, oziroma /null/, če slovar
    // /this/ ne vsebuje podanega ključa.
    //
    private Vozlisce<K, V> poisci(K kljuc) {
        int indeks = this.indeks(kljuc);
        Vozlisce<K, V> vozlisce = this.podatki[indeks];
        while (vozlisce != null && !vozlisce.kljuc.equals(kljuc)) {
            vozlisce = vozlisce.naslednje;
        }
        return vozlisce;
    }

    //
    // Vrne indeks celice zgoščene tabele, ki vsebuje kazalec na začetek
    // povezanega seznama, v katerem se nahaja podani ključ.
    //
    private int indeks(K kljuc) {
        int n = this.podatki.length;
        return ((kljuc.hashCode() % n) + n) % n;
    }

    //
    // Razred za predstavitev iteratorja po ključih slovarja.
    //
    private static class IteratorPoKljucih<K, V> implements Iterator<K> {
        // slovar, po katerem se sprehaja iterator /this/
        private Slovar<K, V> slovar;

        // indeks trenutnega povezanega seznama
        private int indeks;

        // število doslej obiskanih parov ključ-vrednost (oz. ključev)
        private int stevec;

        // trenutno vozlišče v trenutnem povezanem seznamu
        private Vozlisce<K, V> vozlisce;
     
        public IteratorPoKljucih(Slovar<K, V> slovar) {
            this.slovar = slovar;
            this.indeks = -1;
            this.stevec = 0;
            this.vozlisce = null;
        }

        @Override
        public boolean hasNext() {
            return this.stevec < this.slovar.stParov;
        }

        @Override
        public K next() {
            if (!this.hasNext()) {
                throw new NoSuchElementException();
            }

            if (this.indeks < 0 || this.vozlisce.naslednje == null) {
                // poišči naslednji neprazni povezani seznam
                do {
                    this.indeks++;
                } while (this.indeks < this.slovar.podatki.length &&
                        this.slovar.podatki[this.indeks] == null);
                this.vozlisce = this.slovar.podatki[this.indeks];
            } else {
                this.vozlisce = this.vozlisce.naslednje;
            }
            this.stevec++;
            return this.vozlisce.kljuc;
        }
    }

    //
    // Vrne iterator, s katerim se lahko sprehodimo po ključih slovarja /this/.
    //
    @Override
    public Iterator<K> iterator() {
        return new IteratorPoKljucih<K, V>(this);
    }
}
