
//
// Primer nestatičnega notranjega razreda.
//

public class Zunanji {
    private int a;

    public Zunanji(int a) {
        this.a = a;
    }

    public void ustvariNotranji(int b) {
        Notranji notranji = this.new Notranji(b);
        // krajše:
        // Notranji notranji = new Notranji(b);
        notranji.izpisi();
    }

    public class Notranji {
        private int b;

        public Notranji(int b) {
            this.b = b;
        }

        public void izpisi() {
            System.out.println(this.b);
            System.out.println(Zunanji.this.a);
            // krajše:
            // System.out.println(a);
        }
    }
}
