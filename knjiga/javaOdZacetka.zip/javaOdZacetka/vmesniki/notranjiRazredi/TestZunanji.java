
//
// Testni razred za razred Zunanji.
//

public class TestZunanji {

    public static void main(String[] args) {
        Zunanji zunanji = new Zunanji(3);
        zunanji.ustvariNotranji(4);
    }
}
