
//
// Testni razred za razred Vektor.
//

import java.util.*;

public class TestVektor {

    public static void main(String[] args) {
        Vektor<Integer> stevila = new Vektor<>();
        stevila.dodaj(10);
        stevila.dodaj(20);
        stevila.dodaj(30);

        // sprehod z eksplicitnimi klici iteratorjevih metod
        Iterator<Integer> it = stevila.iterator();
        while (it.hasNext()) {
            int element = it.next();
            System.out.println(element);
        }
        System.out.println();

        // sprehod z zanko for-each
        for (int stevilo: stevila) {
            System.out.println(stevilo);
        }
    }
}
