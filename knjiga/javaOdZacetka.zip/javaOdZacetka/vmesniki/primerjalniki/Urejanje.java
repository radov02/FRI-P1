
import java.util.*;

public class Urejanje {

    public static void main(String[] args) {
        Vektor<Oseba> osebe = izdelajVektor();
        System.out.println(osebe);
        System.out.println();

        uredi(osebe);
        System.out.println(osebe);
        System.out.println();

        osebe = izdelajVektor();
        uredi(osebe, Oseba.primerjalnikPoPriimku());
        System.out.println(osebe);
        System.out.println();

        osebe = izdelajVektor();
        uredi(osebe, Oseba.primerjalnikPoSpoluInStarosti());
        System.out.println(osebe);
    }

    private static Vektor<Oseba> izdelajVektor() {
        Vektor<Oseba> osebe = new Vektor<>();
        osebe.dodaj(new Oseba("Milena", "Novak",  'Z', 1957));
        osebe.dodaj(new Oseba("Jure",   "Dolenc", 'M', 1972));
        osebe.dodaj(new Oseba("Jure",   "Novak",  'M', 1978));
        osebe.dodaj(new Oseba("Maja",   "Vovk",   'Z', 2001));
        osebe.dodaj(new Oseba("Marko",  "Dolenc", 'M', 1966));
        osebe.dodaj(new Oseba("Eva",    "Bregar", 'Z', 2007));
        osebe.dodaj(new Oseba("Ana",    "Mihevc", 'Z', 1998));
        osebe.dodaj(new Oseba("Mojca",  "Furlan", 'Z', 1986));
        osebe.dodaj(new Oseba("Peter",  "Bregar", 'M', 1975));
        osebe.dodaj(new Oseba("Ivan",   "Vovk",   'M', 1947));
        return osebe;
    }

    //
    // Elemente podanega vektorja uredi po njihovi naravni urejenosti.
    //
    public static <T extends Comparable<T>> void uredi(Vektor<T> vektor) {
        int stElementov = vektor.steviloElementov();

        for (int i = 1; i < stElementov; i++) {
            T element = vektor.vrni(i);
            int j = i - 1;

            while (j >= 0 && vektor.vrni(j).compareTo(element) > 0) {
                vektor.nastavi(j + 1, vektor.vrni(j));
                j--;
            }
            vektor.nastavi(j + 1, element);
        }
    }

    //
    // Elemente podanega vektorja uredi glede na podani primerjalnik.
    //
    public static <T> void uredi(Vektor<T> vektor, Comparator<T> primerjalnik) {
        int stElementov = vektor.steviloElementov();

        for (int i = 1; i < stElementov; i++) {
            T element = vektor.vrni(i);
            int j = i - 1;

            while (j >= 0 && primerjalnik.compare(vektor.vrni(j), element) > 0) {
                vektor.nastavi(j + 1, vektor.vrni(j));
                j--;
            }
            vektor.nastavi(j + 1, element);
        }
    }
}
