
//
// Testni razred za razred Oseba.
//

public class TestOseba {

    public static void main(String[] args) {
        Oseba a = new Oseba("Janez", "Novak", 'M', 1970);
        Oseba b = new Oseba("Janez", "Breznik", 'M', 1970);
        Oseba c = new Oseba("Marija", "Novak", 'Z', 1970);
        Oseba d = new Oseba("Janez", "Novak", 'M', 1953);

        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
        System.out.println();

        System.out.println(a.compareTo(b));
        System.out.println(a.compareTo(c));
        System.out.println(a.compareTo(d));
    }
}
