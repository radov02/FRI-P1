//
// Razred za predstavitev posameznih pravokotnikov.
//

public class Pravokotnik implements Narisljiv, Izracunljiv {

    // koordinati zgornjega levega kota ter širina in višina
    private int x, y, w, h;

    //
    // Inicializira novoustvarjeni objekt tako, da predstavlja pravokotnik s
    // podanima koordinatama zgornjega levega oglišča (x in y) ter širino (w)
    // in višino (h).
    //
    public Pravokotnik(int x, int y, int w, int h) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }

    @Override
    public void narisi(Platno platno) {
        for (int i = 0;  i <= this.w;  i++) {
            for (int j = 0;  j <= this.h;  j++) {
                platno.pika(this.x + i, this.y + j);
            }
        }
    }

    @Override
    public double ploscina() {
        return this.w * this.h;
    }

    @Override
    public double obseg() {
        return 2 * (this.w + this.h);
    }
}
