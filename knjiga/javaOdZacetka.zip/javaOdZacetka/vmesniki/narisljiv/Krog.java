
//
// Razred za predstavitev posameznih krogov.
//

public class Krog implements Narisljiv, Izracunljiv {

    // koordinati središča in polmer
    private int x, y, r;

    //
    // Inicializira novoustvarjeni objekt tako, da predstavlja krog s podanima
    // koordinatama središča (x in y) ter polmerom (r).
    //
    public Krog(int x, int y, int r) {
        this.x = x;
        this.y = y;
        this.r = r;
    }

    @Override
    public void narisi(Platno platno) {
        for (int i = -this.r;  i <= this.r;  i++) {
            for (int j = -this.r;  j <= this.r;  j++) {
                if (i * i + j * j <= this.r * this.r) {
                    platno.pika(this.x + i, this.y + j);
                }
            }
        }
    }

    @Override
    public double ploscina() {
        return Math.PI * this.r * this.r;
    }

    @Override
    public double obseg() {
        return 2 * Math.PI * this.r;
    }
}
