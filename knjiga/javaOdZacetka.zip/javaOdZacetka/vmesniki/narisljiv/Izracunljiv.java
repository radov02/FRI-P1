
//
// Vmesnik za geometrijske objekte, ki jim lahko izračunamo ploščino in obseg.
//

public interface Izracunljiv {
    //
    // Vrne ploščino objekta /this/.
    //
    public abstract double ploscina();

    //
    // Vrne obseg objekta /this/.
    //
    public abstract double obseg();
}
