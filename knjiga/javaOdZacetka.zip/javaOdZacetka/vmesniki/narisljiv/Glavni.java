
//
// Razred za preizkus hierarhije.
//

public class Glavni {

    public static void main(String[] args) {
        Platno platno = new Platno(50, 30);

        Pravokotnik pravokotnik = new Pravokotnik(3, 2, 8, 15);
        Krog krog = new Krog(30, 15, 12);

        pravokotnik.narisi(platno);
        krog.narisi(platno);

        platno.naZaslon();
    }
}
