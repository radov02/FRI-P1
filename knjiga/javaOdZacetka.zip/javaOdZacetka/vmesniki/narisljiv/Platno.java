
import java.util.Arrays;

//
// Objekt tega razreda predstavlja platno --- podlago za risanje.
//

public class Platno {

    // širina in višina platna
    private int sirina, visina;

    // površina, na katero rišemo
    private boolean[][] povrsina;

    //
    // Novoustvarjeni objekt inicializira tako, da predstavlja platno s podano
    // širino in višino.
    //
    public Platno(int sirina, int visina) {
        this.sirina = sirina;
        this.visina = visina;
        this.povrsina = new boolean[visina][sirina];
    }

    //
    // Na koordinati (x, y) nariše piko.
    //
    public void pika(int x, int y) {
        if (x >= 0 && x < this.sirina && y >= 0 && y < this.visina) {
            this.povrsina[y][x] = true;
        }
    }

    //
    // Počisti platno.
    //
    public void pocisti() {
        for (int i = 0;  i < this.visina;  i++) {
            Arrays.fill(this.povrsina[i], false);
        }
    }

    //
    // Platno prikaže na zaslonu.
    //
    public void naZaslon() {
        for (int i = -1;  i <= this.visina;  i++) {
            for (int j = -1;  j <= this.sirina;  j++) {
                if ((i == -1 || i == this.visina) && (j == -1 || j == this.sirina)) {
                    System.out.print("+ ");
                } else if (i == -1 || i == this.visina) {
                    System.out.print("- ");
                } else if (j == -1 || j == this.sirina) {
                    System.out.print("| ");
                } else {
                    System.out.print(this.povrsina[i][j] ? "* " : "  ");
                }
            }
            System.out.println();
        }
    }
}
