
//
// Vmesnik za geometrijske objekte, ki jih lahko narišemo na platno.
//

public interface Narisljiv {

    //
    // Objekt /this/ nariše na podano platno.
    //
    public abstract void narisi(Platno platno);
}
