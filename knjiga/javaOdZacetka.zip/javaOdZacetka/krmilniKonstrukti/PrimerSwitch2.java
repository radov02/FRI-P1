
//
// Primer s stavkom /switch/.
//

import java.util.Scanner;

public class PrimerSwitch2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String drzava = sc.nextLine().trim();
        String jezik = "";

        switch (drzava) {
            case "Avstrija":
            case "Nemčija":
                jezik = "de";
                break;

            case "Združeno kraljestvo":
            case "Združene države Amerike":
            case "Kanada":
            case "Avstralija":
            case "Nova Zelandija":
                jezik = "en";
                break;
        }

        System.out.println(jezik);
    }
}
