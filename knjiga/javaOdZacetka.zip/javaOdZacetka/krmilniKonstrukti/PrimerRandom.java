
//
// Naključna števila.
//

import java.util.Random;

public class PrimerRandom {

    public static void main(String[] args) {
        Random random = new Random(42);
        int i = 1;
        while (i <= 10) {
            System.out.println(random.nextInt(100));
            i++;
        }
    }
}
