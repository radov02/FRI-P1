
//
// Primer z zanko /while/.
//

public class PrimerWhile {

    public static void main(String[] args) {
        int i = 1;
        while (i <= 3) {
            System.out.println("a");
            i = i + 1;
        }
        System.out.println("b");
    }
}
