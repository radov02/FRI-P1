
//
// Primer s stavkom System.out.printf(...).
//

public class PrimerPrintf1 {

    public static void main(String[] args) {
        int letnik = 4;
        double povprecje = 3.9;
        char crka = 'C';
        String beseda = "java";
        System.out.printf("%d. letnik sem končal s povprečjem %f. " +
                "Programiram v jezikih %s in %c. " +
                "Vrednost izraza 3 < 4 je %b.%n",
                letnik, povprecje, beseda, crka, 3 < 4);
    }
}
