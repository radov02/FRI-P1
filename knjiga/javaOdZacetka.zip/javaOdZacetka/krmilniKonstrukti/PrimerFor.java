
//
// Primer z zanko /for/.
//

public class PrimerFor {

    public static void main(String[] args) {
        for (int i = 1; i <= 3; i++) {
            System.out.println("a");
        }
        System.out.println("b");
    }
}
