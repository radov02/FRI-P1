
//
// Primer z zanko /do/.
//

public class PrimerDo {

    public static void main(String[] args) {
        int i = 1;
        do {
            System.out.println("a");
            i++;
        } while (i <= 3);
        System.out.println("b");
    }
}
