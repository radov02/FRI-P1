
//
// Program prebere število točk (od 100 možnih) in izpiše pripadajočo oceno.
//

import java.util.Scanner;

public class Ocena {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Vnesite število točk: ");
        int tocke = sc.nextInt();

        int ocena = 0;
        if (tocke >= 90) {
            ocena = 10;
        } else if (tocke >= 80) {
            ocena = 9;
        } else if (tocke >= 70) {
            ocena = 8;
        } else if (tocke >= 60) {
            ocena = 7;
        } else if (tocke >= 50) {
            ocena = 6;
        } else {
            ocena = 5;
        }
        System.out.println("Ocena: " + ocena);
    }
}
