
//
// Primer s stavkom System.out.printf(...).
//

public class PrimerPrintf2 {

    public static void main(String[] args) {
        int a = 42;
        double b = 3.1415;
        String niz = "java";
        System.out.printf("[%5d]%n", a);
        System.out.printf("[%10s]%n", niz);
        System.out.printf("[%-5d]%n", a);
        System.out.printf("[%05d]%n", a);
        System.out.printf("[%.3f]%n", b);
        System.out.printf("[%10.3f]%n", b);
    }
}
