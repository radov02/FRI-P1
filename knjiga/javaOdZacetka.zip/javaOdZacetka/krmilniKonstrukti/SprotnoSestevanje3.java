
//
// Program bere števila in jih sproti sešteva, dokler vsota ne preseže 42
// oziroma dokler ne prebere 5 števil.
//

import java.util.Scanner;

public class SprotnoSestevanje3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int stVnosov = 0;
        int vsota = 0;
        while (stVnosov < 5 && vsota <= 42) {
            System.out.print("Vnesite število: ");
            int vnos = sc.nextInt();
            stVnosov = stVnosov + 1;
            vsota = vsota + vnos;
            System.out.println(vsota);
        }
    }
}
