
//
// Program prebere število /n/ in /n/ dolžin skokov v daljino, izpiše pa
// zaporedno številko in dolžino najdaljšega skoka.
//

import java.util.Scanner;

public class Skakalci {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Koliko skakalcev tekmuje? ");
        int stSkakalcev = sc.nextInt();
        int najDolzina = 0;  // doslej največja dolžina skoka
        int najSt = 1;       // zaporedna številka doslej najboljšega skakalca

        for (int st = 1; st <= stSkakalcev; st++) {
            System.out.print("Vnesite dolžino skoka za " + st + ". skakalca: ");
            int dolzina = sc.nextInt();
            if (dolzina > najDolzina) {
                najDolzina = dolzina;
                najSt = st;
            }
        }
        System.out.println("Najboljši je " + najSt + ". skakalec (" + najDolzina + ").");
    }
}
