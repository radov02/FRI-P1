
//
// Stavka /break/ se lahko vedno znebimo ...
//

public class PrimerBreak3 {

    public static void main(String[] args) {
        boolean nadaljuj = true;
        for (int i = 1; i <= 3 && nadaljuj; i++) {
            for (int j = 1; j <= 3 && nadaljuj; j++) {
                System.out.printf("(%d, %d)%n", i, j);
                if (i == 2 && j == 1) {
                    nadaljuj = false;
                }
            }
        }
    }
}
