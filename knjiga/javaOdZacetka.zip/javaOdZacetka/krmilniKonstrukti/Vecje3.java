
//
// Program je povsem enakovreden programu Vecje2, le zapisan je nekoliko
// kompaktneje.
//

import java.util.Scanner;

public class Vecje3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Vnesite prvo število: ");
        int prvo = sc.nextInt();
        System.out.print("Vnesite drugo število: ");
        int drugo = sc.nextInt();

        if (prvo > drugo) {
            System.out.println("Prvo število je večje.");
        } else if (prvo < drugo) {
            System.out.println("Drugo število je večje.");
        } else {
            System.out.println("Števili sta enaki.");
        }
    }
}
