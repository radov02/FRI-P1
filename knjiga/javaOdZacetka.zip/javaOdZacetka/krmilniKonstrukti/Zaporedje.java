
//
// Program prebere števili /a/ in /b/ in izpiše zaporedje a, a + 1, ..., b.
//

import java.util.Scanner;

public class Zaporedje {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Vnesite začetno število: ");
        int a = sc.nextInt();
        System.out.print("Vnesite končno število: ");
        int b = sc.nextInt();

        int stevilo = a;
        while (stevilo <= b) {
            System.out.println(stevilo);
            stevilo = stevilo + 1;
        }
    }
}
