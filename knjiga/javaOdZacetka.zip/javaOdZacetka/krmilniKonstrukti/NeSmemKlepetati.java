
//
// Program 100-krat izpiše vrstico "Ne smem klepetati med poukom.".
//

public class NeSmemKlepetati {

    public static void main(String[] args) {
        int stevec = 1;
        while (stevec <= 100) {
            System.out.println("Ne smem klepetati med poukom.");
            stevec = stevec + 1;
        }
    }
}
