
//
// Program "nadleguje" uporabnika, dokler ta ne vnese števila 42.  Rešitev z
// zanko /while/.
//

import java.util.Scanner;

public class OdgovorWhile {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Vnesite odgovor: ");
        int odgovor = sc.nextInt();
        while (odgovor != 42) {
            System.out.print("Vnesite odgovor: ");
            odgovor = sc.nextInt();
        }
    }
}
