
//
// Prikaz anomalije zanke /for/ (spremenljivka, deklarirana v glavi zanke
// /for/, je vidna zgolj v zanki /for/).
//

public class AnomalijaFor {

    public static void main(String[] args) {
        for (int i = 10; i <= 20; i++) {
            System.out.println(i);
        }

        // Sledeča vrstica uporablja spremenljivko /i/, ki na tem mestu več ne
        // obstaja, zato se program ne prevede.
        System.out.println(i);
    }
}
