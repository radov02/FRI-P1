
//
// Program bere števila in jih sproti sešteva, dokler vsota ne preseže 42.
//

import java.util.Scanner;

public class SprotnoSestevanje1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int vsota = 0;     // vsota doslej prebranih števil
        while (vsota <= 42) {
            System.out.print("Vnesite število: ");
            int vnos = sc.nextInt();
            vsota = vsota + vnos;
            System.out.println(vsota);
        }
    }
}
