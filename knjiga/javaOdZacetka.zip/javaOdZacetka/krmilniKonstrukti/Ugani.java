
//
// Program prebere število /n/ in si izbere naključno število med 1 in /n/,
// nato pa omogoči uporabniku, da ga uganjuje. Po vsakem neuspešnem
// uporabnikovem poskusu izpiše, ali je vneseno število večje ali manjše od
// izbranega.
//

import java.util.*;   // potrebujemo Scanner in Random

public class Ugani {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Vnesite zgornjo mejo: ");
        int meja = sc.nextInt();

        Random random = new Random();
        int izbrano = random.nextInt(meja) + 1;
        int poskus = 0;

        do {
            System.out.print("Vaš poskus: ");
            poskus = sc.nextInt();
            if (izbrano > poskus) {
                System.out.println("Izbrano število je večje.");
            } else if (izbrano < poskus) {
                System.out.println("Izbrano število je manjše.");
            }
        } while (poskus != izbrano);
        System.out.println("Čestitke!");
    }
}
