
//
// Program prebere šolsko oceno in izpiše njen naziv.
//

import java.util.Scanner;

public class NazivOcene {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int ocena = sc.nextInt();

        switch (ocena) {
            case 5:
                System.out.println("odlično");
                break;

            case 4:
                System.out.println("prav dobro");
                break;

            case 3:
                System.out.println("dobro");
                break;

            case 2:
                System.out.println("zadostno");
                break;

            case 1:
                System.out.println("nezadostno");
                break;

            default:
                System.out.println("Neveljavna ocena!");
                break;
        }
    }
}
