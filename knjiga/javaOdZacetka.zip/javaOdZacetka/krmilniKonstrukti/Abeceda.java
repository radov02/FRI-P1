
//
// Program po vrsti izpiše velike črke angleške abecede.
//

public class Abeceda {

    public static void main(String[] args) {
        for (char znak = 'A'; znak <= 'Z'; znak++) {
            System.out.println(znak);
        }
    }
}
