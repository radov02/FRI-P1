
//
// Program "nadleguje" uporabnika, dokler ta ne vnese števila 42.  Rešitev z
// zanko /do/.
//

import java.util.Scanner;

public class OdgovorDo {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int odgovor = 0;
        do {
            System.out.print("Vnesite odgovor: ");
            odgovor = sc.nextInt();
        } while (odgovor != 42);
    }
}
