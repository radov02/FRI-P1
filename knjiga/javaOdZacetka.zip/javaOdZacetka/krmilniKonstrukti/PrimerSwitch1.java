
//
// Primer s stavkom /switch/.
//

import java.util.Scanner;

public class PrimerSwitch1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String jezik = sc.next();

        switch (jezik) {
            case "sl":
                System.out.println("pet");

            case "en":
                System.out.println("five");
                break;

            case "de":
                System.out.println("fünf");

            case "it":
                System.out.println("cinque");

            case "pl":
                System.out.println("pięć");
        }
    }
}
