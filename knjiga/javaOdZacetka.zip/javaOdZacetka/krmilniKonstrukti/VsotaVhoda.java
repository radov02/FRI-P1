
//
// Program izpiše vsoto vseh števil, zapisanih na standardnem vhodu.
//

import java.util.Scanner;

public class VsotaVhoda {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int vsota = 0;
        while (sc.hasNextInt()) {
            int stevilo = sc.nextInt();
            vsota = vsota + stevilo;
        }
        System.out.println(vsota);
    }
}
