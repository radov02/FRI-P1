
//
// Program prebere 5 števil in sproti izpisuje njihovo dotedanjo vsoto.
//

import java.util.Scanner;

public class SprotnoSestevanje2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int stVnosov = 0;   // števec vnosov
        int vsota = 0;      // vsota doslej prebranih števil
        while (stVnosov < 5) {
            System.out.print("Vnesite število: ");
            int vnos = sc.nextInt();
            stVnosov = stVnosov + 1;
            vsota = vsota + vnos;
            System.out.println(vsota);
        }
    }
}
