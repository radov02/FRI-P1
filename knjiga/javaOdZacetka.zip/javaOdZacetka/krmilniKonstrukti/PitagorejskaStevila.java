
//
// Program prebere število /n/ in izpiše število pitagorejskih števil na
// intervalu [1, n].
//

import java.util.Scanner;

public class PitagorejskaStevila {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int meja = sc.nextInt();

        int stPitagorejskih = 0;
        for (int c = 1; c <= meja; c++) {
            // Je število c pitagorejsko?
            srednja:
            for (int a = 1; a < c - 1; a++) {
                for (int b = a + 1; b < c; b++) {
                    if (c * c == a * a + b * b) {
                        //System.out.printf("%d^2 = %d^2 + %d^2%n", c, a, b);
                        stPitagorejskih++;
                        break srednja;
                    }
                }
            }
        }
        System.out.println(stPitagorejskih);
    }
}
