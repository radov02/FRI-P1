
// Program prebere dve števili in izpiše njuno vsoto. Program za razliko od
// programa Vsota1 ne izpisuje spremnega besedila.

import java.util.Scanner;

public class Vsota {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int prvo = sc.nextInt();
        int drugo = sc.nextInt();
        int vsota = prvo + drugo;
        System.out.println(vsota);
    }
}
