#!/bin/bash

for i in {01..10}; do
    echo -n "$i: "
    java $1 < vhod$i.txt > rezultat$i.txt
    if diff rezultat$i.txt izhod$i.txt > /dev/null; then
        echo "pravilno"
    else
        echo "napačno"
    fi
done
