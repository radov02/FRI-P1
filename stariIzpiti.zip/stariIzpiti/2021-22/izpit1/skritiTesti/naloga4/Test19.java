
import java.util.*;

public class Test19 {

    public static void main(String[] args) {
        List<Integer> seznam = List.of(
            87, 350
        );
        System.out.println(Cetrta.odsek(seznam.iterator(), 1, 1));
    }
}
