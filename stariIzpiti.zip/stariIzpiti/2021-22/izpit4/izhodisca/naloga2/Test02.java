
public class Test02 {

    public static void main(String[] args) {
        int m = 10;
        int[][] p = {{6, 5, 2}, {5, 8, 1}, {8, 7, 2}, {3, 4, 2}, {0, 6, 3}};
        System.out.println(Druga.najGlobina(m, p));
    }
}
